<?php
/** henchREDIRECTS v0.0.1 **/

if (!defined('ABSPATH')) exit;

class henchREDIRECTS extends henchPLUGIN {
	protected $version = '0.0.1';
	protected $update_url = 'https://update.henchmen.media/henchREDIRECTS/';
	protected $options = array(
		'priority' => 10,
	);
	protected $admin_page;

	public function setup() {
		add_action('template_redirect', array($this, 'force_ssl'));
		if (!is_admin()) {
			add_action('init', array($this, 'redirect'));
		} else {
			add_filter('hench_dependencies', array($this, 'dependencies'));
			add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));

			$this->admin_page();
			add_filter('hench_admin_page_henchREDIRECTS_values', array($this, 'form_save'), 10, 3);
		}
	}

	public function dependencies($deps=array()){
		$deps[$this->slug()] = array(
			'henchTOOLBOX/henchTOOLBOX.php' => array(
				'name' => 'henchTOOLBOX',
				'url' => 'https://update.henchmen.media/henchTOOLBOX/henchTOOLBOX.zip',
				'version' => '0.0.1',
			),
		);
		return $deps;
	}

	public function admin_enqueue_scripts() {
		wp_register_style('henchREDIRECTSstyle', plugin_dir_url(__FILE__).'style.css');
		wp_enqueue_style('henchREDIRECTSstyle');
	}

	public function admin_page(){
		$redirects = $this->redirect_values();
		$this->admin_page = new henchADMINPAGE(array(
			'parent_slug' => 'henchTOOLBOX',
			'page_title' => 'REDIRECTS',
			'menu_title' => 'Redirects',
			'capability' => 'manage_options',
			'menu_slug' => 'henchREDIRECTS',
			'position' => 10,
			'header_description' => 'Redirect any site url any where. With the power of wild cards and quick entry.',
			'header_icon' => 'dashicons-redo',
			'header_icon_bg' => '#f9943b',
			'content' => '<p>Use the fields below to add and update your Custom Redirects.</p>',
			'form_fields' => array(
				array(
					'name' => 'hench_options',
					'type' => 'fieldset',
					'fields' => array(
						array(
							'name' => 'hench_force_ssl',
							'type' => 'switch',
							'value' => get_option('hench_force_ssl'),
							'option' => array(1=>'Force SSL'),
						),
					),
				),
				array(
					'name' => 'hench_redirects',
					'type' => 'fieldset',
					'label' => 'Redirects',
					'precontent' => '<p>Use the fields below to add and update your Custom Redirects.</p>',
					'id' => 'redirects',
					'multiple' => 1,
					'add' => '+',
					'remove' => '-',
					'fields' => array(
						array(
							'name' => 'path',
							'type' => 'text',
							'placeholder' => '/original-path/',
							'value' => $redirects['path'],
							'class' => 'hench-redirects-path',
						),
						array(
							'name' => 'separator',
							'type' => 'content',
							'value' => '&raquo;',
							'class' => 'hench-redirects-separator',
						),
						array(
							'name' => 'redirect',
							'type' => 'text',
							'placeholder' => '/redirect-path/',
							'value' => $redirects['redirect'],
							'class' => 'hench-redirects-redirect',
						),
					),
				),
				array(
					'name' => 'multiple_redirects',
					'type' => 'textarea',
					'label' => 'Multiple Rules',
					'note' => 'Copy & Paste your rules into the textarea below. One rule per line with a space, comma, or semi-colon separator',
					'placeholder' => '/original-path/ /redirect-path/',
					'class' => 'hench-redirects-multiple',
				),
				array(
					'name' => 'submit',
					'type' => 'submit',
					'value' => 'Save Redirects',
					'cancel' => 'Cancel',
				),
			),
			'docs_url' => 'http://henchmen.media/hench/REDIRECTS/',
			'docs_api' => 'http://henchmen.media/wp-json/wp/v2/help/REDIRECTS/',
		));
	}

	public function admin_help(){
		return '<h4>One to One Internal Redirects</h4>
		<p>You can redirect a page, post, etc. to another page, post, etc. by adding a redirect rule:</p>
		<p>/example.htm -> /example</p>
		<h4>Offsite Redirects</h4>
		<p>You can also redirect links to another site, by adding a redirect rule:</p>
		<p>/example -> http://example.com/</p>
		<h4>Wildcard Single Redirects</h4>
		<p>You can forward all traffic in a folder to a single destination. For example you could forward all blog posts to the home page, if the site no longer has a blog for example, with a redirect rule:</p>
		<p>/blog/* -> /</p>
		<h4>Wildcard Multi-Redirects</h4>
		<p>If you want to use a wildcard that redirects entire folders, like redirecting all pages in the about-us folder to another folder like /about-us/reviews -> /about/reviews and /about-us/locations -> /about/locations you can use the wildcard character to redirect all of these pages with one redirect rule:</p>
		<p>/about-us/* -> /about/*</p>';
	}

	public function form_save($values, $options, $form) {
		$hench_redirects = array();

		update_option('hench_force_ssl', $values['hench_force_ssl']);
		foreach ($values['path'] as $k=>$v) {
			$path = str_ireplace(home_url(), '', $v);
			$redirect = str_ireplace(home_url(), '', $values['redirect'][$k]);
			if (!empty($path)) {
				$hench_redirects[$path] = !empty($redirect) ? $redirect : '/';
			}
		}
		if (!empty($values['multiple_redirects'])) {
			$multi = explode("\n", $values['multiple_redirects']);
			if (count($multi)) {
				foreach ($multi as $redirect) {
					$redirect = str_replace(array(',',';','|','"','\''), ' ', trim($redirect, " \t\n\r\0\x0B,;|\"'"));
					$parts = preg_split('/\s+/', $redirect);
					$parts[0] = str_ireplace(home_url(), '', trim($parts[0]));
					$parts[1] = str_ireplace(home_url(), '', trim($parts[1]));
					if (!empty($parts[0])) {
						$hench_redirects[$parts[0]] = !empty($parts[1]) ? $parts[1] : '/';
					}
				}
			}
		}
		update_option('hench_redirects', $hench_redirects);

		$redirects = $this->redirect_values();
		$form->updateField(array(
			'name' => 'hench_force_ssl',
			'value' => $values['hench_force_ssl'],
		));
		$form->updateField(array(
			'name' => 'path',
			'value' => $redirects['path'],
		));
		$form->updateField(array(
			'name' => 'redirect',
			'value' => $redirects['redirect'],
		));
		$form->reset();
		$form->success('HENCHED: Redirects Saved');
		return array();
	}

	public function redirect() {
		$hench_redirects = get_option('hench_redirects', array());

		$current_url = 'http'.
			(stripos(home_url(), 'https://') === 0 ? 's' : '').
			'://'.
			$_SERVER['HTTP_HOST'].
			$_SERVER['REQUEST_URI'];
		$current_path = str_ireplace(home_url(), '', $current_url);

		if (!empty($hench_redirects[$current_path])) {
			$do_redirect = $hench_redirects[$current_path];
		} else {
			foreach ($hench_redirects as $path=>$redirect) {
				if (strpos($path, '*')!==false) {
					$path = str_replace('*', '(.*)', $path);
					$redirect = str_replace('*', '$1', $redirect);
					$output = preg_replace('|^'.$path.'|', $redirect, $current_path);
					if ($output!=$current_path) {
						$do_redirect = $output;
					}
				}
			}
		}

		if (!empty($do_redirect) && $do_redirect!=$current_path) {
			if (strpos($do_redirect, '/')===0) {
				$do_redirect = home_url().$do_redirect;
			}
			wp_redirect($do_redirect, 301);
			exit();
		}
	}

	public function redirect_values(){
		$hench_redirects = get_option('hench_redirects', array());
		$redirects = array('path'=>array(), 'redirect'=>array());
		foreach ($hench_redirects as $k=>$v) {
			$redirects['path'][] = $k;
			$redirects['redirect'][] = $v;
		}
		return $redirects;
	}

	public function force_ssl(){
		if(get_option('hench_force_ssl') && !is_ssl() && stripos(home_url('/'), 'https://')===0){
			wp_redirect('https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'], 301);
			exit();
		}
	}

}

<?php
/**
 * Plugin Name: henchREDIRECTS
 * Plugin URI: https://henchmenmedia.github.io/
 * Description: henchREDIRECTS gives you a powerful and easy way to create redirects within your WordPress install.
 * Version: 0.0.1
 * Author: Henchmen Media
 * License: GPL3
 **/

if (!defined('ABSPATH')) exit;

require_once(plugin_dir_path(__FILE__).'/henchTOOLBOX.installer.php');

add_action('henchTOOLBOX_setup', function(){
	require_once(plugin_dir_path(__FILE__).'/henchREDIRECTS.class.php');
	henchPLUGIN('henchREDIRECTS');
});

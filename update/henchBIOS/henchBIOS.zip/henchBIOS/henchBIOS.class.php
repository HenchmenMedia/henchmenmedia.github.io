<?php
/** henchBIOS v0.0.1 **/

if (!defined('ABSPATH')) exit;

class henchBIOS extends henchPLUGIN {
	protected $version = '0.0.1';
	protected $update_url = 'https://update.henchmen.media/henchBIOS/';
	protected $options = array(
		'priority' => 10,
	);
	protected $metabox;

	public function setup() {
		add_action('init', array($this, 'add_category'), 1);
		add_action('init', array($this, 'add_custom_post_type'));
		add_shortcode('bios', array($this, 'shortcode'));
		add_action('enqueue_block_editor_assets', array($this, 'enqueue_block_editor_assets'));
		add_action('init', array($this, 'meta_block_init'));
		add_filter('block_categories', array($this, 'block_categories'), 10, 2);
		if (is_admin()) {
			add_filter('hench_dependencies', array($this, 'dependencies'));
			$this->add_metabox();
			add_action('manage_edit-bio_columns', array($this, 'add_admin_column'));
			add_action('manage_bio_posts_custom_column', array($this, 'add_admin_column_print'));
			add_filter('manage_edit-bio_sortable_columns', array($this, 'add_admin_column_sortable'));
		}
	}

	public function dependencies($deps=array()){
		$deps[$this->slug()] = array(
			'henchTOOLBOX/henchTOOLBOX.php' => array(
				'name' => 'henchTOOLBOX',
				'url' => 'https://update.henchmen.media/henchTOOLBOX/henchTOOLBOX.zip',
				'version' => '0.0.1',
			),
		);
		return $deps;
	}

	public function add_category() {
		register_taxonomy('bio_category', 'bio', array(
			'hierarchical' => true,
			'show_in_rest' => true,
			'label' => 'Bio Categories',
		));
	}

	public function add_custom_post_type() {
		$args = array(
			'labels' => array(
				'name' => 'Bios',
				'singular_name' => 'Bio',
			),
			'public' => true,
			'menu_icon' => 'dashicons-businessman',
			'menu_position' => 34,
			'has_archive' => false,
			'can_export' => true,
			'hierarchical' => false,
			'show_in_rest' => true,
			'template' => array(
				array('hench/bio-meta-block', array(
					'align' => 'center',
				)),
				array('core/paragraph', array(
					'placeholder' => 'Add Bio...',
				)),
			),
			'supports' => array('title', 'editor', 'page-attributes', 'excerpt', 'thumbnail', 'revisions'),
			'taxonomies' => array('bio_category'),

		);
		register_post_type('bio', $args);
	}

	public function block_categories($categories, $post){
		return array_merge(
			$categories,
			array(
				array(
					'slug' => 'metaboxes',
					'title' => 'Meta Boxes',
				),
			)
		);
	}

	public function enqueue_block_editor_assets() {
		$current_screen = get_current_screen();
		wp_enqueue_style('hench-bio-blocks', plugin_dir_url(__FILE__).'/blocks/editor.css');
		wp_enqueue_script('hench-bio-blocks', plugin_dir_url(__FILE__).'/blocks/block.js', array('wp-blocks', 'wp-editor', 'wp-element', 'wp-components'));
	}

	public function meta_block_init() {
		register_meta('post', 'fname', array(
			'show_in_rest'  => true,
			'single' => true,
		));
		register_meta('post', 'lname', array(
			'show_in_rest'  => true,
			'single' => true,
		));
		register_meta('post', 'position', array(
			'show_in_rest'  => true,
			'single' => true,
		));
		register_meta('post', 'credentials', array(
			'show_in_rest'  => true,
			'single' => true,
		));
		register_block_type('hench/bio-block', array(
			'render_callback' => array($this, 'shortcode'),
			'attributes' => array(
				'id' => array(
					'type' => 'string',
				),
				'cat' => array(
					'type' => 'string',
				),
				'num' => array(
					'type' => 'integer',
					'default' => -1,
				),
				'orderby' => array(
					'type' => 'string',
					'default' => 'menu_order title',
				),
				'order' => array(
					'type' => 'string',
					'default' => 'ASC',
				),
				'format' => array(
					'type' => 'string',
					'default' => 'image,title,position,content',
				),
				'title_format' => array(
					'type' => 'string',
					'default' => 'title',
				),
				'image_size' => array(
					'type' => 'string',
					'default' => 'medium',
				),
				'link_text' => array(
					'type' => 'string',
					'default' => 'Read More',
				),
				'link_class' => array(
					'type' => 'string',
					'default' => 'button',
				),
				'className' => array(
					'type' => 'string',
				),
			)
		));
	}

	public function add_metabox() {
		$form = new henchForm(array('id'=>'bio_details_form', 'class'=>'hf-default'));
		$form->addField(array(
			'name' => 'fname',
			'label' => 'First Name',
			'type' => 'text',
		));
		$form->addField(array(
			'name' => 'lname',
			'label' => 'Last Name',
			'type' => 'text',
		));
		$form->addField(array(
			'name' => 'position',
			'label' => 'Position',
			'type' => 'text',
		));
		$form->addField(array(
			'name' => 'credentials',
			'label' => 'Credentials',
			'type' => 'text',
		));
		$this->metabox['bio_details'] = new henchMETABOX($form, array(
			'id' => 'bio_details',
			'title' => 'Additional Details',
			'screen' => array('bio'),
			'context' => 'side',
			'priority' => 'core',
			'callback_args' => array(
				'__block_editor_compatible_meta_box' => true,
				'__back_compat_meta_box' => true,
			)
		));
	}

	public function add_admin_column($columns) {
		$columns['menu_order'] = 'Order';
		$columns['position'] = 'Position';
		$columns['credentials'] = 'Credentials';
		return $columns;
	}

	public function add_admin_column_print($name) {
		if ($name=='menu_order') {
			echo get_post_field('menu_order', get_the_ID());
		} elseif ($name=='position') {
			echo get_post_meta(get_the_ID(), 'position', true);
		} elseif ($name=='credentials') {
			echo get_post_meta(get_the_ID(), 'credentials', true);
		}
	}

	public function add_admin_column_sortable($columns) {
		$columns['menu_order'] = 'menu_order';
		$columns['position'] = 'position';
		$columns['credentials'] = 'credentials';
		return $columns;
	}

	public function shortcode($atts) {
		$atts = shortcode_atts(array(
			'id' => '',
			'cat' => '',
			'num' => '-1',
			'orderby' => 'menu_order title',
			'order' => 'ASC',
			'format' => 'image,title,position,content',
			'title_format' => 'title',
			'image_size' => 'medium',
			'link_text' => 'Read More',
			'link_class' => 'button',
			'class' => '',
			'className' => '',
		), $atts);

		$atts['class'] = !empty($atts['className']) ? $atts['className'] : $atts['class'];

		$args = array(
			'post_type' => 'bio',
			'p' => $atts['id'],
			'bio_category' => $atts['cat'],
			'posts_per_page' => $atts['num'],
			'meta_key' => ($atts['orderby'] == 'lname' || $atts['orderby'] == 'fname' ? $atts['orderby'] : ''),
			'orderby' => ($atts['orderby'] == 'lname' || $atts['orderby'] == 'fname' ? 'meta_value' : $atts['orderby']),
			'order' => $atts['order'],
		);

		$bios = get_posts($args);

		$format = explode(',', $atts['format']);
		$format = array_filter(array_map('trim', $format));

		$output = '<div class="hench-bios '.$atts['class'].'">';
		foreach ($bios as $bio) {
			$title = apply_filters('hench_bio_shortcode_title_values', array(
				'title' => $bio->post_title,
				'fname' => get_post_meta($bio->ID, 'fname', true),
				'lname' => get_post_meta($bio->ID, 'lname', true),
				'position' => get_post_meta($bio->ID, 'position', true),
				'credentials' => get_post_meta($bio->ID, 'credentials', true),
			), $atts['title_format'], $bio, $atts);

			$values = array(
				'title' => str_replace(array_keys($title), $title, $atts['title_format']),
				'position' => get_post_meta($bio->ID, 'position', true),
				'credentials' => get_post_meta($bio->ID, 'credentials', true),
				'image' => get_the_post_thumbnail($bio->ID, $atts['image_size']),
				'content' => apply_filters('the_content', $bio->post_content),
				'excerpt' => !empty($bio->post_excerpt) ? $bio->post_excerpt : wp_trim_words($bio->post_content),
				'permalink' => get_the_permalink($bio->ID),
			);

			$html = array(
				'title' => '<h2 class="hench-bio-title">'.$values['title'].'</h2>',
				'position' => '<h3 class="hench-bio-position">'.$values['position'].'</h3>',
				'credentials' => '<div class="hench-bio-credentials">'.$values['credentials'].'</div>',
				'image' => '<div class="hench-bio-image">'.$values['image'].'</div>',
				'content' => '<div class="hench-bio-content">'.$values['content'].'</div>',
				'excerpt' => '<div class="hench-bio-excerpt">'.$values['excerpt'].'</div>',
				'link' => '<a href="'.$values['permalink'].'" class="hench-bio-link '.$atts['link_class'].'">'.$atts['link_text'].'</a>',
			);

			$bio_output = '<div class="hench-bio">';
			foreach($format as $f){
				$bio_output.= apply_filters('hench_bio_shortcode_output_'.$f, (!empty($html[$f]) ? $html[$f] : ''), $values, $atts, $bio);
			}
			$bio_output.= '</div>';

			$output.= apply_filters('hench_bio_shortcode_output_bio', $bio_output, $values, $atts, $bio);
		}
		$output.= '</div>';
		return apply_filters('hench_bio_shortcode_output', $output, $bios, $atts);
	}

}

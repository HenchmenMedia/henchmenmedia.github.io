/**
* henchBIOS
* Version: 0.0.1
**/

var el = wp.element.createElement,
	registerBlockType = wp.blocks.registerBlockType,
	withSelect = wp.data.withSelect,
	RadioControl = wp.components.RadioControl,
	SelectControl = wp.components.SelectControl,
	ToggleControl = wp.components.ToggleControl,
	TextControl = wp.components.TextControl,
	ServerSideRender = wp.components.ServerSideRender,
	Fragment = wp.element.Fragment,
	InspectorControls = wp.editor.InspectorControls;

document.addEventListener('DOMContentLoaded', function() {
	if (document.querySelector('.post-type-bio')) {
		bioMetaBlock();
	}
	bioBlock();
});

/*
 * Bio Post Type Meta Block
 */
function bioMetaBlock() {
	registerBlockType( 'hench/bio-meta-block', {
		title: 'Bio Meta Block',
		icon: 'admin-users',
		category: 'metaboxes',
		supports: {
			multiple: false,
			customClassName: false,
		},
		attributes: {
			fname: {
				type: 'string',
				source: 'meta',
				meta: 'fname'
			},
			lname: {
				type: 'string',
				source: 'meta',
				meta: 'lname'
			},
			position: {
				type: 'string',
				source: 'meta',
				meta: 'position'
			},
			credentials: {
				type: 'string',
				source: 'meta',
				meta: 'credentials'
			}
		},

		edit: function(props) {
			var fname = props.attributes.fname;
			var lname = props.attributes.lname;
			var position = props.attributes.position;
			var credentials = props.attributes.credentials;

			return [
				el(TextControl, {
					type: 'string',
					label: 'First Name',
					value: fname,
					onChange: function(newFname) {props.setAttributes({ fname: newFname })},
				}),
				el(TextControl, {
					type: 'string',
					label: 'Last Name',
					value: lname,
					onChange: function(newLname) {props.setAttributes({ lname: newLname })},
				}),
				el(TextControl, {
					type: 'string',
					label: 'Position',
					value: position,
					onChange: function(newPosition) {props.setAttributes({ position: newPosition })},
				}),
				el(TextControl, {
					type: 'string',
					label: 'Credentials',
					value: credentials,
					onChange: function(newCredentials) {props.setAttributes({ credentials: newCredentials })},
				})
			];
		},

		save: function() {
			return null;
		},
	});
}

/*
 * Bio Block
 */
function bioBlock() {
	registerBlockType( 'hench/bio-block', {
		title: 'Bio',
		icon: 'admin-users',
		category: 'widgets',
		supports: {
			customClassName: false,
		},
		attributes: {
			id: {
				type: 'string',
			},
			cat: {
				type: 'string',
			},
			num: {
				type: 'integer',
				default: -1,
			},
			orderby: {
				type: 'string',
				default: 'menu_order title',
			},
			order: {
				type: 'string',
				default: 'ASC',
			},
			format: {
				type: 'string',
				default: 'image,title,position,content',
			},
			title_format: {
				type: 'string',
				default: 'title',
			},
			image_size: {
				type: 'string',
				default: 'medium',
			},
			link_text: {
				type: 'string',
				default: 'Read More',
			},
			link_class: {
				type: 'string',
				default: '',
			},
			className: {
				type: 'string',
			},
		},

		edit: withSelect( getBioOptions )( function(props) {
			var id = props.attributes.id;
			var cat = props.attributes.cat;
			var num = props.attributes.num;
			var orderby = props.attributes.orderby;
			var order = props.attributes.order;
			var format = props.attributes.format;
			var title_format = props.attributes.title_format;
			var image_size = props.attributes.image_size;
			var link_text = props.attributes.link_text;
			var link_class = props.attributes.link_class;
			var className = props.attributes.className;

			return (
				el(
					Fragment,
					null,
					el(
						InspectorControls,
						null,
						el(SelectControl, {
							type: 'select',
							label: 'Display by ID',
							value: id,
							options: props.bioOptions,
							onChange: function(newId) {props.setAttributes({ id: newId })},
						}),
						el(SelectControl, {
							type: 'select',
							label: 'Display by Category',
							value: cat,
							options: props.bioCategoryOptions,
							onChange: function(newCat) {props.setAttributes({ cat: newCat })},
						}),
						el(TextControl, {
							type: 'number',
							label: 'Number of Bios',
							value: num,
							onChange: function(newNum) {props.setAttributes({ num: newNum })},
						}),
						el(SelectControl, {
							type: 'select',
							label: 'Order By',
							value: orderby,
							options: [
								{ value: 'menu_order title', label: 'Menu Order' },
								{ value: 'publish_date', label: 'Publish Date' },
								{ value: 'fname', label: 'First Name' },
								{ value: 'lname', label: 'Last Name' },
								{ value: 'position', label: 'Position' },
								{ value: 'title', label: 'Title' }
							],
							onChange: function(newOrderby) {props.setAttributes({ orderby: newOrderby })},
						}),
						el(RadioControl, {
							type: 'radio',
							label: 'Order',
							selected: order,
							options: [
								{ value: 'ASC', label: 'ASC' },
								{ value: 'DESC', label: 'DESC' }
							],
							onChange: function(newOrder) {props.setAttributes({ order: newOrder })},
						}),
						el(TextControl, {
							type: 'text',
							label: 'Format',
							value: format,
							onChange: function(newFormat) {props.setAttributes({ format: newFormat })},
						}),
						el(TextControl, {
							type: 'text',
							label: 'Custom Display Name',
							value: title_format,
							onChange: function(newTitleFormat) {props.setAttributes({ title_format: newTitleFormat })},
						}),
						el(SelectControl, {
							type: 'select',
							label: 'Featured Image Size',
							value: image_size,
							options: [
								{ value: 'thumbnail', label: 'Thumbnail' },
								{ value: 'medium', label: 'Medium' },
								{ value: 'full', label: 'Full' }
							],
							onChange: function(newImageSize) {props.setAttributes({ image_size: newImageSize })},
						}),
						el(TextControl, {
							type: 'text',
							label: 'Link Text',
							value: link_text,
							onChange: function(newLinkText) {props.setAttributes({ link_text: newLinkText })},
						}),
						el(TextControl, {
							type: 'text',
							label: 'Link Class',
							value: link_class,
							onChange: function(newLinkClass) {props.setAttributes({ link_class: newLinkClass })},
						}),
						el(TextControl, {
							type: 'text',
							label: 'Custom Wrapper Class',
							value: className,
							onChange: function(newClassName) {props.setAttributes({ className: newClassName })},
						}),
					),
					el(ServerSideRender, {
						block: 'hench/bio-block',
						attributes: props.attributes
					})
				)
			);
		}),

		save: function() {
			return null;
		},
	});
}

function getBioOptions(select,props) {
	console.log(props);
	var bios = select('core').getEntityRecords('postType', 'bio');
	var bioCats = select('core').getEntityRecords('taxonomy', 'bio_category');
	var bio_options = [];
	if (bios) {
		for (var x = 0; x < bios.length; x++) {
			bio_options[x] = {
				value: bios[x].id,
				label: bios[x].title.rendered
			};
		}
	}
	bio_options.unshift({value: '', label: 'All'});

	var bio_category_options = [];
	if (bioCats) {
		for (var i= 0; i < bioCats.length; i++) {
			bio_category_options[i] = {
				value: bioCats[i].slug,
				label: bioCats[i].name
			};
		}
	}
	bio_category_options.unshift({value: '', label: 'All'});

	return {
		bioOptions: bio_options,
		bioCategoryOptions: bio_category_options
	};
}

<?php

add_action('admin_init', function(){
	$slug = 'henchTOOLBOX/henchTOOLBOX.php';
	$url = 'https://update.henchmen.media/henchTOOLBOX/henchTOOLBOX.zip';
	if(!is_plugin_active($slug)){
		if(!current_user_can('update_plugins')){ return false; }
		require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';
		$installed_plugins = get_plugins();
		if(!isset($installed_plugins[$slug])){
			echo '<div style="display: none;">';
			$upgrader = new Plugin_Upgrader();
			$upgrader->install($url);
			echo '</div>';
		}
		is_network_admin() ? activate_plugin($slug, null, true) : activate_plugin($slug);
		echo '<script>window.location.reload();</script>';
	}
});

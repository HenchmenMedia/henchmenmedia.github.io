<?php
/**
 * Plugin Name: henchBIOS
 * Plugin URI: https://henchmenmedia.github.io/
 * Description: henchBIOS gives you a powerful and easy way to create staff bios.
 * Version: 0.0.1
 * Author: Henchmen Media
 * License: GPL3
 **/

if (!defined('ABSPATH')) exit;

require_once(plugin_dir_path(__FILE__).'/henchTOOLBOX.installer.php');

add_action('henchTOOLBOX_setup', function(){
	require_once(plugin_dir_path(__FILE__).'/henchBIOS.class.php');
	henchPLUGIN('henchBIOS');
});

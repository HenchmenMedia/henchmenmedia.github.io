<?php
/**
 * henchFORM_lib
 * Description: henchFORM_lib adds the henchFORM library to the henchTOOLBOX.
 * GitHub: https://github.com/HenchmenMedia/henchFORM
 * Docs: https://henchmenmedia.github.io/
 * Version: 0.0.1
 * Author: Henchmen Media
 * License: GPL3
**/

if (!defined('ABSPATH')) exit;

class henchFORM_lib extends henchPLUGIN {
	protected $version = '0.0.1';
	protected $options = array(
		'priority' => 2,
	);

	public function setup(){
		add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
		add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
		require_once(henchPATH.'hench/FORM/henchFORM.php');
	}

	/*public function options_form($fields=array()) {
		return parent::options_form(array(
			array(
				'name' => $this->slug().'_frontend',
				'type' => 'checkbox',
				'label' => 'Load henchFORM on the Frontend',
				'value' => $this->option($this->slug().'_frontend') ?: array(),
				'option' => array(
					'script' => 'Include henchFORM.js on Frontend Pages',
					'style' => 'Include henchFORM.css on Frontend Pages',
				),
			),
		));
	}*/

	public function save_options($form) {
		$value = $form->postValues();
		$this->set_option($this->slug().'_frontend', !empty($value[$this->slug().'_frontend']) ? $value[$this->slug().'_frontend'] : array());
	}

	public function enqueue_scripts() {
		$frontend = $this->option($this->slug().'_frontend');
		if(is_admin() || apply_filters($this->slug().'_frontend_script', is_array($frontend) && in_array('script', $frontend) ? true : false)){
			wp_register_script($this->slug().'_script', henchURL.'hench/FORM/js/henchFORM.min.js');
			wp_enqueue_script($this->slug().'_script');
		}
		if(is_admin() || apply_filters($this->slug().'_frontend_style', is_array($frontend) && in_array('style', $frontend) ? true : false)){
			wp_register_style($this->slug().'_style', henchURL.'hench/FORM/css/henchFORM.min.css');
			wp_enqueue_style($this->slug().'_style');
		}
	}

}

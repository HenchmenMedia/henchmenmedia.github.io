<?php
/**
 * henchADMIN
 * Description: henchADMIN is designed to give developers a powerful and easy to use WordPress admin panel.
 * Version: 0.0.1
**/

if (!defined('ABSPATH')) exit;

class henchADMIN extends henchPLUGIN {
	protected $version = '0.0.1';
	protected $options = array(
		'priority' => 9,
	);
	protected $admin_page;

	public function setup(){
		add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
		$this->admin_page();
	}

	public function admin_page(){
		$phrases = array(
			'Henching everything in sight with powerful tools.',
			'We like to kick WordPress in the teeth and then have it thank us.',
			'Henchmen, fixing WordPress one plugin at a time.',
		);
		shuffle($phrases);
		$page_settings = array(
			'page_title' => 'TOOLBOX',
			'menu_title' => 'TOOLBOX',
			'capability' => 'manage_options',
			'menu_slug' => 'henchTOOLBOX',
			'icon_url' => 'dashicons-hammer',
			'position' => 120,
			'hench_header' => true,
			'header_description' => $phrases[0],
			'header_icon' => 'dashicons-hammer',
			'header_icon_bg' => '#23d0d4',
			'content' => array($this, 'admin_content'),

			'form_fields' => array(
				array(
					'name' => 'hench_magic_urls',
					'type' => 'switch',
					'value' => get_option('hench_magic_urls'),
					'option' => array(1=>'Magic URLS'),
					'class' => 'hench-switch',
					'postcontent' => '<p>Save Post, Page & CPT content with dynamic urls. "Wait? What? No more search and replace?" <a href="https://henchmen.media/hench/TOOLBOX/magic-urls/" target="_blank">Full Details</a></p>'.(get_option('hench_magic_urls')==1 ? '<p>Run magic urls replacer</p>' : '<p>Run magic urls remover</p>'),
				),
				array(
					'name' => 'hench_custom_loop',
					'type' => 'switch',
					'value' => get_option('hench_custom_loop'),
					'option' => array(1=>'Custom Loop'),
					'class' => 'hench-switch',
					'postcontent' => '<p>Create custom html structure for custom post types without programming, shortcodes or extra plugins. <a href="https://henchmen.media/hench/TOOLBOX/custom-loop/" target="_blank">Full Details</a></p>',
				),
				array(
					'name' => 'submit',
					'type' => 'submit',
					'value' => 'Save Settings',
					'cancel' => 'Cancel',
				),
			),
			'docs_url' => 'http://henchmen.media/hench/TOOLBOX/',
			'docs_api' => 'http://henchmen.media/wp-json/wp/v2/help/TOOLBOX/',
		);
		$this->admin_page = new henchADMINPAGE($page_settings);
		add_action('admin_menu', array($this, 'change_submenu'), 999);
	}

	public function change_submenu(){
		global $submenu;
		if(!empty($submenu['henchTOOLBOX'][0][0])){
			$submenu['henchTOOLBOX'][0][0] = 'Settings';
		}
	}

	public function admin_enqueue_scripts(){
		wp_register_style('henchADMIN_style', henchURL.'css/style.css');
		wp_enqueue_style('henchADMIN_style');
	}

	public function admin_content(){
		echo '<p>henchTOOLBOX is chock-full of useful WordPress functionality that you never knew you have always wanted.</p>';
		echo '<p>Here are a few of those amazing features:</p>';
	}

}

<?php
/**
 * henchPLUGIN
 * Description: henchPLUGIN is designed to give developers a powerful and easy way to create robust plugins. All henchPLUGINS are extended from the henchPLUGIN class.
 * Version: 0.0.1
**/

if (!defined('ABSPATH')) exit;

class henchTHEME extends henchPLUGIN {

	public function __construct() {
		parent::__construct();
		$this->check_theme_update();
	}

	public function check_plugin_update_url($transient){
		return $transient;
	}

	private function check_theme_update(){
		if(is_admin() && !empty($this->update_url) && strpos($this->update_url, 'wordpress.org')===false){
			add_filter('pre_set_site_transient_update_themes', array($this, 'check_theme_update_url'));
		}
	}

	public function check_theme_update_url($transient){
		if (empty($transient->checked[$this->slug()])) {
			return $transient;
		}

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->update_url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 3);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$result = curl_exec($ch);
		curl_close($ch);

		if (empty($result)) {
			return $transient;
		}

		if ($data = json_decode($result)) {
			if (version_compare($transient->checked[$this->slug()], $data->new_version, '<')) {
				$transient->response[$this->slug()] = (array) $data;
			}
		}

		return $transient;
	}

	protected function setup_actions(){
		add_action('after_setup_theme', array($this, 'setup_action'), $this->options['priority']);
	}

}

<?php
/**
 * henchDEPENDENCY
 * Description: henchDEPENDENCY is designed to give developers a powerful and easy to use WordPress plugin dependency system.
 * Version: 0.0.1
**/

if (!defined('ABSPATH')) exit;

class henchDEPENDENCY extends henchPLUGIN {
	protected $version = '0.0.1';
	protected $options = array(
		'priority' => 2,
	);
	protected $dependents = '';
	protected $dependencies;

	public function setup(){
		add_action('admin_init', array($this, 'check'), 9999);
	}

	public function check(){
		$this->dependencies = apply_filters('hench_dependencies', array());
		foreach($this->dependencies as $dependent=>$dependencies){
			$this->dependents.= '<li>'.$dependent.'</li>';
			foreach($dependencies as $slug=>$atts){
				$this->plugin_actions($slug);
				if(!is_plugin_active($slug) && is_array($atts) && !empty($atts['url'])){
					$this->install($slug, $atts['url']);
				}
			}
		}
	}

	public function plugin_actions($slug){
		add_filter('network_admin_plugin_action_links_'.$slug, array($this, 'modify_actions'));
		add_filter('plugin_action_links_'.$slug, array($this, 'modify_actions'));
		add_action('after_plugin_row_'.$slug, function($slug){
			echo '<script>jQuery(".active[data-plugin=\''.$slug.'\'] .check-column input").remove();</script>';
		});
	}

	public function modify_actions($actions){
		unset($actions['edit']);
		unset($actions['delete']);
		unset($actions['deactivate']);
		$actions['required-plugin'] = '<span class="network_active">Required by:<ul class="hench-dependents">'.$this->dependents.'</ul></span>';
		return $actions;
	}

	public function install($slug, $url){
		if(!current_user_can('update_plugins')){ return false; }
		$plugins = get_plugins();
		if(!isset($plugins[$slug])){
			require_once(ABSPATH.'wp-admin/includes/class-wp-upgrader.php');
			echo '<div style="display: none;">';
			$upgrader = new Plugin_Upgrader();
			$result = $upgrader->install($url);
			echo '</div>';
		}
		$result = is_network_admin() ? activate_plugin($slug, null, true) : activate_plugin($slug);
	}

}

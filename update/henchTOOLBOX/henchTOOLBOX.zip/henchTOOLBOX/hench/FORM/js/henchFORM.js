document.addEventListener('DOMContentLoaded', henchFORM);

function henchFORM(){
	for(const form of document.querySelectorAll('.hf_form_tag')){
		form.noValidate = true;
		form.setAttribute('data-invalid', '0');
		form.onsubmit = function(e){
			var submit = form.querySelector('.hf_submit');
			submit.setAttribute('disabled', 'disabled');
			form.setAttribute('data-submitted', '1');
			form.setAttribute('data-invalid', '0');
			if(!form.checkValidity()){
				e.preventDefault();
				for(const field of form.querySelectorAll('.hf_field')){
					for(const input of field.querySelectorAll('.hf_input')){
						hf_isValid(input, field);
					}
				}
				submit.removeAttribute('disabled');
			}
		}

		for(const field of form.querySelectorAll('.hf_dependency')){
			field.style.display = 'none';
		}

		for(const fieldset of form.querySelectorAll('.hf_fieldset')){
			fieldset.addEventListener('click', hf_addRemove);
		}

		for(const field of form.querySelectorAll('.hf_field')){
			for(const input of field.querySelectorAll('.hf_input')){
				hf_setupInput(input, field);
			}
		}

	}

}

function hf_setupInput(input, field){
	input.addEventListener('focus', function(){
		field.classList.add('hf-focus');
		field.classList.remove('hf-blur');
	});
	input.addEventListener('blur', function(){
		field.classList.add('hf-blur');
		field.classList.remove('hf-focus');
	});
	if(hf_parentWithClass(field, 'hf_multiple')){
		input.addEventListener('input', function(){ hf_isValid(input, field); });
		input.addEventListener('change', function(){ hf_isValid(input, field); });
	} else {
		input.addEventListener('input', function(){ hf_isValid(input, field); hf_checkDependency(input); });
		input.addEventListener('change', function(){ hf_isValid(input, field); hf_checkDependency(input); });
		hf_checkDependency(input);
	}
}

function hf_addRemove(e){
	if(e.target.matches('.hf_multiple_add') || e.target.matches('.hf_multiple_remove')){
		e.preventDefault();
		var group = hf_parentWithClass(e.target, 'hf_fields');
		var groups;
		var field;
		var label;
		var pattern;
		if(group){
			var newGroup = group.cloneNode(true);
			hf_unsetValues(newGroup);
			if(e.target.matches('.hf_multiple_add')){
				newGroup = group.insertAdjacentElement('afterend', newGroup);
			} else if(e.target.matches('.hf_multiple_remove')){
				groups = this.querySelectorAll('.hf_fields');
				if(groups.length==1){
					newGroup = group.insertAdjacentElement('beforebegin', newGroup);
				}
				group.remove();
			}
			groups = this.querySelectorAll('.hf_fields');
			for(var i=0;i<groups.length;i++){
				groups[i].setAttribute('data-count', i+1);
				for(const input of groups[i].querySelectorAll('.hf_input')){
					input.setAttribute('name', input.getAttribute('name').replace(/\[[0-9]+\]/, '['+(i)+']'));
					input.setAttribute('id', input.getAttribute('id').replace(/([^_]*)(_[0-9]*)(_[0-9]+)(_[0-9]+)?/, '$1$2_'+(i)+'$4'));
					field = hf_parentWithClass(input, 'hf_field');
					label = field.querySelector('.hf-label');
					if(label && label.getAttribute('for')){
						label.setAttribute('for', input.getAttribute('id'));
					}
					hf_setupInput(input, field);
				}
			}
			this.querySelector('.hf_count').value = groups.length;
		}
	}
}

function hf_unsetValues(group){
	for(const field of group.querySelectorAll('.hf_field')){
		field.classList.remove('hf-valid', 'hf-invalid', 'hf-blur', 'hf-focus');
	}
	for(const input of group.querySelectorAll('.hf_input')){
		switch(input.getAttribute('type')){
			case 'radio':
				input.checked = false;
				break;
			case 'checkbox':
				input.checked = false;
				break;
			case 'select':
				input.selectedIndex = -1;
				break;
			case 'textarea':
				input.innerHTML = '';
				break;
			default:
				input.value = '';
		}
	}
}

function hf_parentWithClass(obj, cls){
	while((obj = obj.parentElement) && !obj.classList.contains(cls));
	return obj;
}

function hf_isValid(input, field){
	if(input.form.getAttribute('data-submitted')=='1' && !input.checkValidity()){
		if(input.form.getAttribute('data-invalid')=='0'){
			input.form.setAttribute('data-invalid', '1');
			input.focus();
		}
		field.classList.add('hf-invalid');
		field.classList.remove('hf-valid');
		field.querySelector('.hf_field_error').innerHTML = '<label class="hf-error-label" for="'+input.getAttribute('id')+'">'+input.validationMessage+'</label>';
		return false;
	} else if(input.form.getAttribute('data-submitted')=='1'){
		field.classList.remove('hf-invalid');
		field.classList.add('hf-valid');
		return true;
	}
}

function hf_checkDependencyValue(value, input, field){
	var tag = input.tagName.toLowerCase();
	if(tag=='textarea' || tag=='select'){ var type = tag; }
	else if(input.getAttribute('type')) { var type = input.getAttribute('type').toLowerCase(); }
	else { var type = 'text'; }
	if(value==undefined){ value = ''; }

	if(tag=='select'){
		if(value=='' && input.options[input.selectedIndex].value!=''){ return true; }
		if(value!='' && input.options[input.selectedIndex].value==value){ return true; }
	} else if(type=='radio' || type=='checkbox'){
		for(option of field.querySelectorAll('.hf_input')){
			if(value=='' && option.checked && option.value!=''){ return true; }
			if(value!='' && option.checked && option.value==value){ return true; }
		}
	} else {
		if(value=='' && input.value!=''){ return true; }
		if(value!='' && input.value==value){ return true; }
	}
	return false;
}

function hf_checkDependency(input){
	var name = input.getAttribute('name');
	for(const field of input.form.querySelectorAll('.hf_dependency_'+name)){
		var value = field.getAttribute('data-dependency-value');
		var check = hf_checkDependencyValue(value, input, input.form.querySelector('.hf_field_'+name));
		if(check && input.form.querySelector('.hf_field_'+name).style.display!='none'){
			if(field.style.display=='none'){
				field.style.display = '';
				var fieldinput = field.querySelector('.hf_input');
				if(fieldinput){ hf_checkDependency(fieldinput); }
			}
		} else {
			if(field.style.display!='none'){
				field.style.display = 'none';
				var fieldinput = field.querySelector('.hf_input');
				if(fieldinput){ hf_checkDependency(fieldinput); }
			}
		}
	}
}

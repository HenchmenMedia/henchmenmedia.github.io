
# henchFORM #

henchFORM is designed to give developers a fast and easy way to create robust forms.

### Dependencies ###

- PHP 7
- Javascript ES5


### Basic Usage ###

#### Step 1: Include Required Files ####

**PHP Class**
```
require_once('path_to_library/henchFORM.php');
```

**CSS Files (Optional)**
```
<link href="path_to_library/css/henchFORM.css" rel="stylesheet" type="text/css" />
```

**Javascript Files**
```
<script type="text/javascript" src="path_to_library/js/henchFORM.js"></script>
```

#### Step 2: Assign new henchFORM Class ####

```
$form = new henchFORM();
```

#### Step 3: Add Fields ####

```
$form->addField(array(
	'name' => 'email',
	'type' => 'email',
	'label' => 'Email Address',
	'placeholder' => 'me@example.com',
	'value' => '',
	'required' => true,
));
```

#### Step 4: Add Submit Button ####

```
$form->addField(array(
	'name' => 'submit',
	'type' => 'submit',
	'value' => 'Register',
	'class' => 'register-button',
	'cancel' => 'I already have an account',
	'cancel_url' => 'http://henchmen.media/login/',
	'cancel_class' => 'cancel-button',
));
```

### Step 5: Add Value Processing Functions ###

```
$form->addHook('success', 'formSuccess');

function formSuccess($form){
	$values = $form->postValues();
	// Do something with these form values

	// If values processing was successful
	// Unset field values for single use forms like contact forms etc.
	$form->reset();

	// Set success message
	$form->success('Success: The form worked');
}
```

#### Step 6: Print Form ####

```
echo $form->getHTML();
```

### Available Field Types ###

Here are the available field types:

- **checkbox** - Standard checkbox field(s)
- **content** - Used to insert html content in between different form fields
- **color** - Standard color field*
- **date** - Standard date field*
- **datetime** - Standard datetime field*
- **datetime-local** - Standard datetime-local field*
- **email** - Standard email field with email error checking
- **file** - Not yet supported
- **hidden** - Standard hidden field
- **number** - Standard number field*
- **password** - Standard password field
- **radio** - Standard radio field(s)
- **range** - Standard range field
- **search** - Standard search field
- **select** - Standard drop down select field
- **submit** - Standard submit button with the option for a cancel link
- **tel** - Standard tel field
- **text** (default) - Standard text field
- **textarea** - Standard textarea field
- **time** - Standard time field*
- **url** - Standard url field with url error checking
- **wysiwyg** - Not yet supported

\* Weak browser support

**Additional WordPress Field Types**

- **wp_media** - File upload using the standard WP Media pop-up and attachment functions
- **wp_media_image** - Image upload using the standard WP Media pop-up and attachment functions designed specifically for images only
- **wp_wysiwyg** - The standard WP editor


### Field Options ###

Standard options available for all field types, unless otherwise specified below under Special Field Options:

- **autocomplete** - Standard autocomplete attribute
- **autofocus** - Standard autofocus attribute
- **class** - Standard class attribute, adds class to field container not field input
- **disabled** - Standard disabled attribute
- **error** - Error text for this field
- **error_status** - Error status for this field
- **id** - Standard id attribute, if id is not explicitly set an id of hf_{name} will be used by default
- **label** - Standard label tag set to the field
- **max** - Standard max attribute for range field type
- **maxlength** - Standard maxlength attribute
- **min** - Standard min attribute for range field type
- **minlength** - Standard minlength attribute
- **name** - Standard name attribute
- **note** - Note that is appended to the label
- **option** - An array of values used to generate the list of options for select, checkbox and radio field types. The keys of the array are the set to the option values and the array values are the set to the option labels. If no keys are provided the array values are both the option values and the option labels.
- **pattern** - Not yet supported, used to add a custom regular expression for error processing
- **placeholder** - Standard placeholder attribute
- **postcontent** - Content that is placed after the label, input and error tag
- **precontent** - Content that is placed before the label and input field
- **readonly** - Standard readonly attribute
- **required** - Standard required attribute
- **size** - Standard size attribute
- **step** - Standard step attribute for range field type
- **tabindex** - Standard tabindex attribute
- **template** - HTML template used to generate this field, overrides default template if set
- **type** - Standard type attribute, available options listed above in Field Types
- **value** - Standard value attribute


### Special Field Type Attributes/Options ###

**Hidden**

- **class** - Not supported

**Submit**

The following cancel attributes are used to add an option link next to the submit button that takes the user away from the form
- **cancel** - content for cancel anchor tag
- **cancel_url** - href value for the cancel anchor tag
- **cancel_id** - id for the cancel anchor tag
- **cancel_target** - target for the cancel anchor tag
- **cancel_class** - class(es) for the cancel anchor tag

### Error Messages ###

Error messages are pulled directly from the browser and placed after the form field in a div. This provides automatic error handling, automatic internationalization and provides the ability to style the errors to match your site.

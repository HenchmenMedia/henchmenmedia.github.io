<?php

class henchFORM_radio extends henchFORM_field {

	public function setup(){
		$this->error('required', 'Please select one of these options.');
		parent::setup();
		if(!is_array($this->setting('option'))){
			$this->setting('option', array());
		} elseif(is_array($this->setting('option'))){
			if(array_keys($this->setting('option'))===range(0, count($this->setting('option')) - 1)){
				foreach($this->setting('option') as $ol){
					$option[$ol] = $ol;
				}
				$this->setting('option', $option);
			}
		}
	}

	public function value(){
		parent::value();
		if(is_array($this->value) && !array_key_exists($this->value, $this->setting('option'))){
			$this->value = '';
		}
		return $this->value;
	}

	public function fieldInputHTML(){
		$html = '<span class="hf-options">';
		$i = 0;
		foreach($this->setting('option') as $k=>$v){
			$html.= '<span class="hf-option"><label class="hf-option-label"><input type="radio" name="'.$this->fieldName().'" value="'.$k.'" id="'.$this->fieldId($i).'" class="hf_input hf_radio hf-radio"'.
				(($this->value==$k || (is_array($this->value) && in_array($k, $this->value))) ? ' checked' : '')
			.$this->attributes().' /><span class="hf-option-label-text">'.$v.'</span></label></span>';
			$i++;
		}
		$html.= '</span>';
		return $html;
	}

	public function fieldId($i=0){
		return parent::fieldId().'_'.$i;
	}

	public function fieldLabelFor(){
		return '';
	}

}

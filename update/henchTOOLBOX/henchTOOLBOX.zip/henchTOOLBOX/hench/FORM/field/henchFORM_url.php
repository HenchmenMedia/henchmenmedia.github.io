<?php

class henchFORM_url extends henchFORM_field {

	public function __construct($form, $setting=array()){
		$this->error('invalid', 'Please input a valid URL.');
		parent::__construct($form, $setting);
	}

	public function validate(){
		if(!empty($this->value) && !filter_var($this->value, FILTER_VALIDATE_URL, FILTER_FLAG_SCHEME_REQUIRED)){
			$this->failed('invalid');
			return false;
		}
		return true;
	}

}

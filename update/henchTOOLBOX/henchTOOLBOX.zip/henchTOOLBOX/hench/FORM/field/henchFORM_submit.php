<?php

class henchFORM_submit extends henchFORM_field {

	public function parse(){
		return;
	}

	public function html(){
		return '
			<div class="'.$this->cssClasses().'"'.$this->dependencyHTML().'>'.
				$this->precontentHTML().
				$this->fieldHTML().
				$this->postcontentHTML().
				'
			</div>';
	}

	public function fieldInputHTML(){
		return '<input type="submit" value="'.$this->setting('value').'" class="hf_submit hf-submit" id="'.$this->fieldId().'"'.$this->attributes().' /><span class="hf-loader"></span> '.($this->setting('cancel') ? $this->cancelHTML() : '');
	}

	public function cancelHTML(){
		return '<a href="'.$this->setting('cancel_url').'" class="hf-cancel '.$this->setting('cancel_class').'"'.
			($this->setting('cancel_id') ? ' id="'.$this->setting('cancel_id').$this->setting('num').'"' : '')
			.''.
			($this->setting('cancel_target') ? ' target="'.$this->setting('cancel_target').'"' : '')
			.'>'.$this->setting('cancel').'</a>';
	}

}

<?php

class henchFORM_select extends henchFORM_field {

	public function setup(){
		$this->error('required', 'Please select an item in the list.');
		parent::setup();
		if(!is_array($this->setting('option'))){
			$this->setting('option', array());
		}
		if(!is_array($this->setting('option'))){
			$this->setting('option', array());
		} elseif(is_array($this->setting('option'))){
			if(array_keys($this->setting('option'))===range(0, count($this->setting('option')) - 1)){
				foreach($this->setting('option') as $ol){
					$option[$ol] = $ol;
				}
				$this->setting('option', $option);
			}
		}
	}

	public function value(){
		parent::value();
		if(is_array($this->value) && !array_key_exists($this->value, $this->setting('option'))){
			$this->value = '';
		}
		return $this->value;
	}

	public function fieldInputHTML(){
		$html = '<select name="'.$this->fieldName().'" id="'.$this->fieldId().'" class="hf_input hf-input hf-input-'.$this->setting('type').'"'.$this->attributes().'>';
		$html.= $this->setting('placeholder') ? '<option value="">'.$this->setting('placeholder').'</opiton>' : '';
		foreach($this->setting('option') as $k=>$v){
			$html.= '
			<option value="'.$k.'"'.(($this->value==$k || (is_array($this->value) && in_array($k, $this->value))) ? ' selected' : '').'>'.$v.'</option>';
		}
		$html.= '</select>';
		return $html;
	}

}

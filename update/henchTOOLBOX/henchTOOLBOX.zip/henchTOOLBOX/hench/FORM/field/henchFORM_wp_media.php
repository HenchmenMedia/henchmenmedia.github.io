<?php

class henchFORM_wp_media extends henchFORM_field {

	public function setup(){
		parent::setup();
		if(empty($this->setting('placeholder'))){ $this->setting('placeholder', 'No file selected...'); }
		if(empty($this->setting('add'))){ $this->setting('add', 'Choose or Upload a File'); }
		if(empty($this->setting('remove'))){ $this->setting('remove', 'Clear Selection'); }
	}

	public function parse(){
		$this->status = 1;
		$this->value();
		$this->getAttachment();
		if($this->status==1){
			$this->checkRequired();
			$this->validate();
			$this->customValidate();
		}
		$this->form_value();
	}

	public function validate(){
		if(!empty($this->value) && empty($this->setting('attachment'))){
			$this->failed('required');
			return false;
		}
		return true;
	}

	public function getAttachment(){
		if(function_exists('get_attached_file')){
			if(!empty($this->value)){
				$attachment = basename(get_attached_file($this->value));
			}
			if(!empty($attachment)){
				$this->setting('attachment', $attachment);
			} else {
				$this->setting('attachment', '');
			}
		}
	}

	public function fieldInputHTML(){
		if(function_exists('wp_enqueue_media')){
			wp_enqueue_media();
			return '<div class="hf-media-preview" data-default="'.$this->setting('placeholder').'">'.$this->setting('attachment').'</div>
				<input type="hidden" name="'.$this->fieldName().'" value="'.$this->value.'" id="'.$this->fieldId().'" class="hf-input hf-input-'.$this->setting('type').'"'.$this->attributes().' />
				<button type="button" class="hf-button hf-media-button">'.$this->setting('add').'</button>
				<button type="button" class="hf-button hf-remove-button">'.$this->setting('remove').'</button>';
		} else {
			return 'This field type can only be used within WordPress.';
		}
	}

}

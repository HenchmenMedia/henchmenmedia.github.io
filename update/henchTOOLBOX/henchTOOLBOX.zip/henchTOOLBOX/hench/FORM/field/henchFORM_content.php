<?php

class henchFORM_content extends henchFORM_field {
	public $value = null;

	public function html(){
		return '
			<div class="'.$this->cssClasses().'"'.$this->dependencyHTML().'>'.
				$this->precontentHTML().
				$this->fieldHTML().
				$this->postcontentHTML().
				'
			</div>';
	}

	public function parse(){
		return;
	}

	public function fieldHTML(){
		return '<div class="hf-content" id="'.$this->fieldId().'">'.$this->setting('value').'</div>';
	}

}

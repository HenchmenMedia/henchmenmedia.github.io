<?php

class henchFORM_tel extends henchFORM_field {

	public function __construct($form, $setting=array()){
		$this->error('invalid', 'Please input a valid Telephone Number.');
		parent::__construct($form, $setting);
	}

	public function validate(){
		if(!empty($this->value) && !filter_var($this->value, FILTER_CALLBACK, array(
				'options' => array(
					'callback' => array($this, 'filter_tel'),
				),
			)
		)){
			$this->failed('invalid');
			return false;
		}
		return true;
	}

	public function filter_tel($val){
		if(preg_match('/^(\d[\s-]?)?[\(\[\s-]{0,2}?\d{3}[\)\]\s-]{0,2}?\d{3}[\s-]?\d{4}$/i', $val)){
			return true;
		} else {
			return false;
		}
	}

}

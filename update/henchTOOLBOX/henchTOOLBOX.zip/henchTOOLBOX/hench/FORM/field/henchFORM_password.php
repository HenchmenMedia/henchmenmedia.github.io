<?php

class henchFORM_password extends henchFORM_field {

	public function fieldInputHTML(){
		return '<input type="'.$this->setting('type').'" name="'.$this->fieldName().'" value="" id="'.$this->fieldId().'" class="hf_input hf-input hf-input-'.$this->setting('type').'"'.$this->attributes().' />';
	}

}

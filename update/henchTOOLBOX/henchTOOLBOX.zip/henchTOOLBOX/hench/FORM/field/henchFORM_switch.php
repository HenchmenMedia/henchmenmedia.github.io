<?php

class henchFORM_switch extends henchFORM_field {

	public function setup(){
		parent::setup();
		$this->setting['required'] = '';
		if(!is_array($this->setting('option'))){
			$this->setting('option', array());
		} elseif(is_array($this->setting('option'))){
			if(array_keys($this->setting('option'))===range(0, count($this->setting('option')) - 1)){
				foreach($this->setting('option') as $ol){
					$option[$ol] = $ol;
				}
				$this->setting('option', $option);
			}
		}
	}

	public function value(){
		parent::value();
		if(!empty($this->value) && is_array($this->value)){
			foreach($this->value as $k=>$v){
				if(empty($v) || !array_key_exists($v, $this->setting('option'))){
					unset($this->value[$k]);
				}
			}
		} elseif(is_array($this->value) && !array_key_exists($this->value, $this->setting('option'))){
			$this->value = '';
		}
		return $this->value;
	}

	public function fieldInputHTML(){
		$html = '<span class="hf-switches">';
		$i = 0;
		foreach($this->setting('option') as $k=>$v){
			$html.= '<span class="hf-switch"><label class="hf-switch-label"><input type="checkbox" name="'.$this->fieldName().'" value="'.$k.'" id="'.$this->fieldId($i).'" class="hf_input hf_checkbox hf-checkbox"'.
				(($this->value==$k || (is_array($this->value) && in_array($k, $this->value))) ? ' checked' : '')
			.$this->attributes().' /><span class="hf-switch-box"><span class="hf-switch-box-on"></span><span class="hf-switch-box-off"></span></span></label><span class="hf-switch-label-text">'.$v.'</span></span>';
			$i++;
		}
		$html.= '</span>';
		return $html;
	}

	public function fieldName(){
		return parent::fieldName().(count($this->setting('option'))>1 ? '[]' : '');
	}

	public function fieldId($i=0){
		return parent::fieldId().'_'.$i;
	}

	public function fieldLabelFor(){
		return '';
	}

}

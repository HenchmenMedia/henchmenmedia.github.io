<?php

class henchFORM_field {
	protected $form;
	protected $setting = array();
	protected $error = array('required' => 'Please fill out this field.', 'pattern' => 'Please input a valid value.');
	public $value = '';
	public $status = 0;
	public $message = '';

	public function __construct($form, $setting=array()){
		$this->form = $form;
		$this->setting($setting);
	}

	public function setting($key='', $val=false){
		if(is_array($key)){
			if(!empty($key['error'])){
				$this->error($key['error']);
				unset($key['error']);
			}
			$this->setting = array_merge($this->setting, $key);
			$val = true;
			$this->setup();
		} elseif($key && $val!==false){
			$this->setting[$key] = $val;
			$this->setup();
		} elseif($key && isset($this->setting[$key])){
			$val = $this->setting[$key];
		}
		return $val;
	}

	public function error($key='', $error=false){
		if(is_array($key)){
			$this->error = array_merge($this->error, $key);
			$error = true;
		} elseif($key && $error!==false){
			$this->error[$key] = $error;
		} elseif($key && isset($this->error[$key])){
			$error = $this->error[$key];
		}
		return $error;
	}

	public function setup(){
		if(!$this->setting('type')){ $this->setting('type', 'text'); }
	}

	public function parse(){
		$this->value();
		if($this->status==1){
			$this->checkRequired();
			$this->validate();
			$this->customValidate();
		}
		$this->form_value();
	}

	public function value(){
		if($this->form->submitted){
			$this->status = 1;
			$val = isset($_POST[$this->setting('name')]) ? $_POST[$this->setting('name')] : '';
		}

		$count = $this->setting('count');

		if(isset($val) && is_array($val) && count($val) && $count!==false){
			$val = (isset($val[$count-1])) ? $val[$count-1] : '';
		} elseif(isset($val)){
			$val = $val;
		} elseif($count!==false){
			$val = $this->setting('value');
			$val = (!empty($val[$count-1])) ? $val[$count-1] : '';
		} else {
			$val = $this->setting('value');
		}

		$this->value = $val;

		return $this->value;
	}

	public function reset(){
		$this->status = 0;
		$this->value = $this->setting('value');
		return true;
	}

	public function checkRequired(){
		if($this->checkDependency()){
			if($this->setting('required') && empty($this->value)){
				$this->failed('required');
				return false;
			}
		}
		return true;
	}

	public function checkDependency(){
		if($this->setting('dependency')){
			$depval = $this->form->field[$this->setting('dependency')]->value();
			if($depval!='' && $this->setting('dependency-value')==''){ return true; }
			if($depval!='' && $depval==$this->setting('dependency-value')){ return true; }
			return false;
		}
		return true;
	}

	public function validate(){
		return true;
	}

	public function customValidate(){
		if(is_callable($this->setting('validate'))){
			$this->setting('validate')($this->value);
		}
	}

	public function form_value(){
		if($this->setting('count')){
			$this->form->value[$this->setting('name')][$this->setting('count')-1] = $this->value;
		} else {
			$this->form->value[$this->setting('name')] = $this->value;
		}
	}

	public function failed($type='required', $args=array()){
		if(!empty($type) && $this->error($type)){
			$this->message = sprintf($this->error($type), $args);
		}
		$this->status = 2;
	}

	public function html(){
		//if(!$this->status){ $this->value(); }
		$this->parse();
		return '
			<div class="'.$this->cssClasses().'"'.$this->dependencyHTML().'>'.
				$this->precontentHTML().
				$this->labelHTML().
				$this->fieldHTML().
				$this->errorHTML().
				$this->postcontentHTML().
				'
			</div>';
	}

	public function cssClasses(){
		if($this->status==2){ $valid_class = ' hf-invalid'; }
		elseif($this->status==1){ $valid_class = ' hf-valid'; }
		else { $valid_class = ''; }
		$dependency = preg_replace('/(\[\])/', '', $this->setting('dependency'));
		$dependency_class = $dependency ? ' hf_dependency hf_dependency_'.$dependency : '';
		return 'hf_field hf_field_'.$this->setting('name').$dependency_class.$valid_class.' hf-field hf-field-'.$this->setting('type').' '.$this->setting('class');
	}

	public function dependencyHTML(){
		return ($this->setting('dependency') ? ' data-dependency="'.$this->setting('dependency').'"' : '').
		($this->setting('dependency-value') ? ' data-dependency-value="'.$this->setting('dependency-value').'"' : '');
	}

	public function precontentHTML(){
		return ($this->setting('precontent') ? '
			<div class="hf-precontent">'.$this->setting('precontent').'</div>' : '');
	}

	public function labelHTML(){
		return ($this->setting('label') ? '
			<label class="hf-label"'.$this->fieldLabelFor().'><span class="hf-label-name">'.$this->setting('label').'</span>'.
				($this->setting('note') ? ' <span class="hf-label-note">'.$this->setting('note').'</span>' : '')
			.'</label>' : '');
	}

	public function fieldHTML(){
		return '<span class="hf-field-input">
			'.$this->fieldInputHTML().'
		</span>';
	}

	public function fieldInputHTML(){
		return '<input type="'.$this->setting('type').'" name="'.$this->fieldName().'" data-name="'.$this->setting('name').'" value="'.$this->value.'" id="'.$this->fieldId().'" class="hf_input hf-input hf-input-'.$this->setting('type').'"'.$this->attributes().' />';
	}

	public function fieldName(){
		return $this->setting('name').($this->setting('count') ? '['.($this->setting('count')-1).']' : '');
	}

	public function fieldId(){
		return 'hf_'.$this->setting('name')
			.($this->setting('num') ? '_'.$this->setting('num') : '')
			.($this->setting('count') ? '_'.($this->setting('count')-1) : '');
	}

	public function fieldLabelFor(){
		return ' for="'.$this->fieldId().'"';
	}

	public function errorHTML(){
		return '
			<span class="hf_field_error hf-field-error">'.
				($this->status==2 ? '<label id="'.$this->fieldId().'-error" class="hf_error hf-error hf_error_label hf-error-label"'.$this->fieldLabelFor().'>'.$this->message.'</label>' : '')
			.'</span>';
	}

	public function postcontentHTML(){
		return ($this->setting('postcontent') ? '
			<div class="hf-postcontent">'.$this->setting('postcontent').'</div>' : '');
	}

	public function attributes(){
		$attr = array('autofocus', 'disabled', 'readonly', 'required', 'multiple');
		$attributes = '';
		foreach($attr as $a){
			$attributes.= (!empty($this->setting($a))) ? ' '.$a : '';
		}

		$attr = array('autocomplete', 'maxlength', 'minlength', 'min', 'max', 'pattern', 'placeholder', 'size', 'tabindex');
		foreach($attr as $a){
			$attributes.= (!empty($this->setting($a))) ? ' '.$a.'="'.$this->setting($a).'"' : '';
		}

		return $attributes;
	}

}

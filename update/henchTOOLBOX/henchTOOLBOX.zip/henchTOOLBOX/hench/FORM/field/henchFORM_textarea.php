<?php

class henchFORM_textarea extends henchFORM_field {

	public function fieldInputHTML(){
		return '<textarea name="'.$this->fieldName().'" id="'.$this->fieldId().'" class="hf_input hf-input hf-textarea"'.$this->attributes().'>'.$this->value().'</textarea>';
	}

}

<?php

class henchFORM_fieldset extends henchFORM_field {
	public $value = null;

	public function total(){
		$total = 1;
		if(isset($_POST[$this->setting('name').'-count'])){
			$total = $_POST[$this->setting('name').'-count'];
		} elseif(is_array($this->form->field[$this->setting('fields')[0]]->setting('value'))) {
			$total = count($this->form->field[$this->setting('fields')[0]]->setting('value'));
		} elseif($this->setting('count')){
			$total = $this->setting('count');
		}
		return !empty($total) ? $total : 1;
	}

	public function parse(){
		$count = 1;
		$total = $this->total();
		while($count<=$total){
			foreach($this->setting('fields') as $field){
				$f = $this->form->field[$field];
				if($this->setting('multiple')){ $f->setting('count', $count); }
				$f->parse();
			}
			$count++;
		}
		$this->form->value[$this->setting('name').'-count'] = $total;
		return;
	}

	public function html(){
		return '
			<div class="'.$this->cssClasses().'" data-name="'.$this->setting('name').'" '.$this->dependencyHTML().'>'.
				$this->labelHTML().
				$this->precontentHTML().
				$this->fieldsHTML().
				$this->postcontentHTML().
			'</div>';
	}

	public function cssClasses(){
		return 'hf_fieldset hf_fieldset_'.$this->setting('name')
			.($this->setting('dependency') ? ' hf_dependency hf_dependency_'.$this->setting('dependency') : '')
			.($this->setting('multiple') ? ' hf_multiple' : '')
			.' hf-fieldset '
			.$this->setting('class');
	}

	public function labelHTML(){
		return ($this->setting('label') ? '
			<div class="hf-fieldset-label"><span class="hf-fieldset-label-name">'.$this->setting('label').'</span></div>' : '');
	}

	public function precontentHTML(){
		return ($this->setting('precontent') ? '
			<div class="hf-fieldset-precontent">'.$this->setting('precontent').'</div>' : '');
	}

	public function fieldsHTML(){
		$count = 1;
		$total = $this->total();
		$html = '';
		while($count<=$total){
			$html.= '<div class="hf_fields hf-fields" data-count="'.$count.'">';
			foreach($this->setting('fields') as $field){
				$f = $this->form->field[$field];
				if($this->form->num){ $f->setting('num', $this->form->num); }
				if($this->setting('multiple')){ $f->setting('count', $count); }
				if($f->setting('name')=='hfmessage'){
					$f->status = $this->status;
					$f->message = $this->status==1 ? $this->success : $this->error;
				}

				if($f->setting('type')=='fieldset'){
					$fieldset = $f;
					$html.= $f->html();
				} elseif(empty($fieldset) || !in_array($f->setting('name'), $fieldset->setting('fields'))){
					unset($fieldset);
					$html.= $f->html();
				}
			}
			if($this->setting('add') || $this->setting('remove')){
				$html.= '<div class="hf-multiple-actions">';
				if($this->setting('add')){
					$html.= '<button type="button" class="hf_multiple_add hf-multiple-add">'.$this->setting('add').'</button>';
				}
				if($this->setting('remove')){
					$html.= '<button type="button" class="hf_multiple_remove hf-multiple-remove">'.$this->setting('remove').'</button>';
				}
				$html.= '</div>';
			}
			$html.= '</div>';
			$count++;
		}
		if($this->setting('multiple')){
			$html.= '<input type="hidden" name="'.$this->setting('name').'-count" value="'.$total.'" class="hf_count" />';
		}

		return $html;
	}

	public function postcontentHTML(){
		return ($this->setting('postcontent') ? '
			<div class="hf-fieldset-postcontent">'.$this->setting('postcontent').'</div>' : '');
	}

}

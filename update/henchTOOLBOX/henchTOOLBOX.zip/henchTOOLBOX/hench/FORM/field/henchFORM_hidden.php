<?php

class henchFORM_hidden extends henchFORM_field {

	public function html(){
		return $this->fieldInputHTML();
	}

	public function fieldInputHTML(){
		return '<input type="'.$this->setting('type').'" name="'.$this->fieldName().'" value="'.$this->value().'" id="'.$this->fieldId().'" class="hf_input hf-input hf-input-'.$this->setting('type').'"'.$this->attributes().' />';
	}

}

<?php

class henchFORM_wp_media_image extends henchFORM_field {

	public function setup(){
		parent::setup();
		if(empty($this->setting('placeholder')) && function_exists('home_url')){ $this->setting('placeholder', home_url('/').'wp-includes/images/media/default.png'); }
		if(empty($this->setting('add'))){ $this->setting('add', 'Choose or Upload a Image'); }
		if(empty($this->setting('remove'))){ $this->setting('remove', 'Clear Selection'); }
	}

	public function parse(){
		$this->status = 1;
		$this->value();
		$this->getImage();
		if($this->status==1){
			$this->checkRequired();
			$this->validate();
			$this->customValidate();
		}
		$this->form_value();
	}

	public function validate(){
		if(!empty($this->value) && empty($this->setting('image'))){
			$this->failed('required');
			return false;
		}
		return true;
	}

	public function getImage(){
		if(function_exists('wp_get_attachment_image_src')){
			if(!empty($this->value)){
				$image = wp_get_attachment_image_src($this->value, 'medium');
			}
			if(is_array($image) && !empty($image[0])){
				$this->setting('image', $image[0]);
			} else {
				$this->setting('image', '');
			}
		}
	}

	public function fieldInputHTML(){
		if(function_exists('wp_enqueue_media')){
			wp_enqueue_media();
			return '<div class="hf-media_image-preview" data-default="'.$this->setting('placeholder').'">'.$this->setting('image').'</div>
				<input type="hidden" name="'.$this->fieldName().'" value="'.$this->value.'" id="'.$this->fieldId().'" class="hf-input hf-input-'.$this->setting('type').'"'.$this->attributes().' />
				<button type="button" class="hf-button hf-media_image-button">'.$this->setting('add').'</button>
				<button type="button" class="hf-button hf-remove-button">'.$this->setting('remove').'</button>';
		} else {
			return 'This field type can only be used within WordPress.';
		}
	}

}

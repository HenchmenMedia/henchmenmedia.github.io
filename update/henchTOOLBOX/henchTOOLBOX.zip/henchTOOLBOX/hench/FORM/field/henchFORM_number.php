<?php

class henchFORM_number extends henchFORM_field {

	public function __construct($form, $setting=array()){
		$this->error('invalid', 'Please input a valid Number.');
		$this->error('min', 'Value must be greater than or equal to %d.');
		$this->error('max', 'Value must be less than or equal to %d.');
		parent::__construct($form, $setting);
	}

	public function validate(){
		if(!empty($this->value) && !filter_var($this->value, FILTER_VALIDATE_FLOAT)){
			$this->failed('invalid');
			return false;
		}
		if(!empty($this->value) && $this->setting('min') && $this->value<$this->setting('min')){
			$this->failed('min', $this->setting('min'));
			return false;
		}
		if(!empty($this->value) && $this->setting('max') && $this->value>$this->setting('max')){
			$this->failed('max', $this->setting('max'));
			return false;
		}
		return true;
	}

}

<?php

class henchFORM_wp_wysiwyg extends henchFORM_field {

	public function fieldInputHTML(){
		if(function_exists('wp_editor')){
			if($this->setting('editor-style')){
				add_theme_support('editor-style');
				global $editor_styles;
				$editor_styles = array_merge((array) $editor_styles, array('editor-style.css'));
			}
			ob_start();
			wp_editor($this->value, $this->fieldId(), array('textarea_name'=>$this->fieldName(),'textarea_rows'=>$this->setting('rows'), 'tabindex'=>$this->setting('tabindex')));
			$editor = ob_get_contents();
			ob_end_clean();
			return $editor;
		} else {
			return 'This field type can only be used within WordPress.';
		}
	}

}

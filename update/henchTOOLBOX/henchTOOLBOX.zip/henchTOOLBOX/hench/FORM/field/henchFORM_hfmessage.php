<?php

class henchFORM_hfmessage extends henchFORM_field {
	public $value = null;
	public $message;

	public function parse(){
		return;
	}

	public function html(){
		return $this->fieldHTML();
	}

	public function fieldHTML(){
		if($this->status){
			return '<div class="hf-submit-message">
				<div class="hf-message hf-submit-'.($this->status==1 ? 'success' : 'error').'">'.$this->message.'</div>
			</div>';
		}
	}

}

<?php

spl_autoload_register(function($class){
	if(file_exists(__DIR__.'/field/'.$class.'.php')){
		include_once __DIR__.'/field/'.$class.'.php';
	}
});

class henchFORM {
	protected $hook = array(
		'success'=> array(),
		'failed' => array(),
	);
	protected $setting = array(
		'enctype' => 'multipart/form-data',
		'autocomplete' => 'on',
		'accept-charset' => 'UTF-8',
		'target' => '_self',
	);
	protected $error = 'Error: Check your input values and try again';
	protected $success = 'Success: Thank You for Your Submission';
	public $num = 1;
	public $field = array();
	public $submitted = 0;
	public $value = array();
	public $status = 0;

	public function __construct($setting=array()){
		$this->setting($setting);
	}

	public function setting($key='', $val=false){
		if(is_array($key)){
			$this->setting = array_merge($this->setting, $key);
			$val = true;
			$this->setup();
		} elseif($key && $val!==false){
			$this->setting[$key] = $val;
			$this->setup();
		} elseif($key && isset($this->setting[$key])){
			$val = $this->setting[$key];
		}
		return $val;
	}

	public function setup(){
		if(!$this->setting('id')){
			if(isset($this->value['hf-form']) && $this->value['hf-form']){
				$this->setting('id', $this->value['hf-form']);
			} else {
				$this->setting('id', uniqid('hfform_', true));
			}
		}
	}

	public function addHook($hook, $function){
		$this->hook[$hook][] = $function;
	}

	protected function callHook($hook){
		foreach($this->hook[$hook] as $func){
			if(is_array($func) && is_object($func[0])){
				if(method_exists($func[0], $func[1])){
					call_user_func($func, $this);
				}
			} else {
				if(function_exists($func)){
					call_user_func($func, $this);
				}
			}
		}
	}

	public function postValues(){
		return $this->value;
	}

	public function reset(){
		$this->submitted = 0;
		foreach($this->field as $f){
			$f->reset();
		}
		unset($_POST);
	}

	public function failed($error=''){
		if($error){ $this->error = $error; }
		$this->status = 2;
	}

	public function fieldFailed($name, $type='', $args=array()){
		if(!empty($name) && !empty($type) && !empty($this->field[$name])){
			$this->field[$name]->failed($type, $args);
		}
		$this->failed();
	}

	public function success($success=''){
		if($success){ $this->success = $success; }
		$this->status = 1;
	}

	public function classFieldName($type){
		return 'henchFORM_'.strtolower($type);
	}

	public function addField($setting=array()){
		if(empty($setting['name'])){ return false; }
		if($setting['name']=='hfmessage'){ $setting['type'] = 'hfmessage'; }

		if($setting['type']=='fieldset' && count($setting['fields'])){
			$fields = $setting['fields'];
			$setting['fields'] = array();
			foreach($fields as $field){
				$setting['fields'][] = $field['name'];
			}
		}

		$class = $this->classFieldName($setting['type']);
		if(class_exists($class, true)){
			$this->field[$setting['name']] = new $class($this, $setting);
		} else {
			$this->field[$setting['name']] = new henchFORM_field($this, $setting);
		}

		if($setting['type']=='fieldset' && count($fields)){
			foreach($fields as $field){
				$this->addField($field);
			}
		}

	}

	public function addFields($fields=array()){
		foreach($fields as $field){
			$this->addField($field);
		}
	}

	public function updateField($setting=array()){
		if(empty($setting['name'])){ return false; }
		$this->field[$setting['name']]->setting($setting);
	}

	public function updateFields($fields=array()){
		foreach($fields as $field){
			$this->updateField($field);
		}
	}

	public function submitted(){
		if(isset($_POST['hf-form']) && $_POST['hf-form']==$this->setting['id'] && isset($_POST['hf-form-num']) && $_POST['hf-form-num']==$this->num){
			$this->submitted = 1;
		} else {
			$this->submitted = 0;
		}
		return $this->submitted;
	}

	public function parseForm(){
		$this->status = 0;
		if($this->submitted()){
			$this->status = 1;
			foreach($this->field as $f){
				$f->parse();
				if($f->status==2){ $this->status = 2; }
				//$this->value[$f->setting('name')] = $f->value;
			}
			if($this->status==1){
				$this->success();
				$this->callHook('success');
			}
			if($this->status==2){
				$this->failed();
				$this->callHook('failed');
				return false;
			}
			return true;
		} elseif(isset($_POST['hf-form']) && $_POST['hf-form']==$this->setting['id']){
			$this->reset();
		}
		return false;
	}

	public function getHTML($print_form_tag=true){
		$this->parseForm();
		$html = '<div class="hf_form hf-form '.$this->setting['class'].'">';
		if($print_form_tag){
			$html.= '<form method="post" novalidate="novalidate" ';
			foreach($this->setting as $k=>$v){
				switch($k){
					case 'class':
						$html.= ' class="hf_form_tag hf-form-tag"';
						break;
					case 'id':
						$html.= ' id="'.$v.'_'.$this->num.'"';
						break;
					default:
						if($v!==''){
							$html.= ' '.$k.'="'.$v.'"';
						}
						break;
				}
			}
			$html.= '>'."\n";
		}
		$html.= '<input type="hidden" class="hf_input hf-input hf-input-hidden" name="hf-form" value="'.$this->setting['id'].'" /><input type="hidden" class="hf_input hf-input hf-input-hidden" name="hf-form-num" value="'.$this->num.'" />';

		if(!array_key_exists('hfmessage', $this->field)){
			$this->addField(array('name'=>'hfmessage'));
		}
		foreach($this->field as $f){
			if($this->num){ $f->setting('num', $this->num); }
			if($f->setting('name')=='hfmessage'){
				$f->status = $this->status;
				$f->message = $this->status==1 ? $this->success : $this->error;
			}

			if($f->setting('type')=='fieldset'){
				$fieldset = $f;
				$html.= $f->html();
			} elseif(empty($fieldset) || !in_array($f->setting('name'), $fieldset->setting('fields'))){
				unset($fieldset);
				$html.= $f->html();
			}
		}
		if($print_form_tag){
			$html.= '</form>'."\n";
		}
		$html.= '</div>'."\n";

		// Used when you need to print the same form on the same page more than once.
		$this->num++;
		return $html;
	}

}

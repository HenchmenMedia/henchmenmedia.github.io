<?php

require_once('henchFORM.php');

function formSuccess($form){
	$v = $form->postValues();
	$form->success('Success: Your Account Has Been Created.');
	//$form->reset();
}
function formFailed($form){
	$v = $form->postValues();
	$form->failed('Error: Something Went Wrong.');
}

$form = new henchFORM(array('id'=>'test_form', 'class'=>'hf-box test_form'));
$form->addHook('success', 'formSuccess');
$form->addHook('failed', 'formFailed');
$form->addField(array(
	'name' => 'silent',
	'type' => 'hidden',
	'value' => 'test',
));
$form->addField(array(
	'name' => 'user_id',
	'type' => 'number',
	'label' => 'User Id:',
	'required' => true,
	'min' => 3,
	'max' => 10,
	'id' => 'user_id',
));
$form->addField(array(
	'name' => 'email',
	'type' => 'email',
	'label' => 'Email Address:',
	'value' => 'clonge@fuelmedical.com',
	'precontent' => '<p>Pre Content: stuff that goes before the form field if any.</p>',
	'note' => 'Email is a required field.',
	'required' => true,
	'id' => 'email',
	'placeholder' => 'example@domain.com',
	'postcontent' => '<p>Post Content: stuff that goes after the form field if any.</p>',
	'error' => array('registered' => 'Email Address Already Registered.'),
	'validate' => function($value) use ($form){
		if($value=='test@example.com'){
			$form->fieldFailed('email', 'registered');
		}
	},
));
$form->addField(array(
	'name' => 'fields',
	'type' => 'fieldset',
	'label' => 'Test Fields',
	'id' => 'testFields',
	'dependency' => 'email',
	'multiple' => 1,
	'add' => '+',
	'remove' => '-',
	'count' => 2,
	'fields' => array(
		array(
			'name' => 'name',
			'type' => 'text',
			'label' => 'Name:',
			'required' => 1,
			'id' => 'name',
			'placeholder' => 'John Smith',
			'dependency' => 'email',
		),
		array(
			'name' => 'url',
			'type' => 'url',
			'label' => 'URL:',
			'required' => 0,
			'id' => 'url',
			'placeholder' => 'http://google.com/',
		),
		array(
			'name' => 'yes',
			'type' => 'radio',
			'label' => 'Are you sure?',
			'option' => array('yes','no'),
			'required' => 1,
			'id' => 'yes',
			//'dependency' => 'email',
		),
	),
));
/*$form->addField(array(
	'name' => 'dependencies',
	'type' => 'fieldset',
	'dependency' => 'name',
	'multiple' => 1,
	'add' => '+',
	'remove' => '-',
	'count' => 2,
), array(
	array(
		'name' => 'notifications',
		'type' => 'checkbox',
		'label' => 'Do you want to be notified?',
		'option' => array('yes'=>'Yes', 'no'=>'No'),
		'id' => 'notifications',
		'dependency' => 'name',
	),
	array(
		'name' => 'options',
		'type' => 'select',
		'label' => 'Select an option:',
		'placeholder' => 'Select...',
		'option' => array('yes'=>'Yes','no'=>'No', 'maybe'=>'Maybe'),
		'required' => 1,
		'id' => 'options',
		'dependency' => 'name',
	),
	array(
		'name' => 'comments',
		'type' => 'textarea',
		'label' => 'Comments:',
		'placeholder' => 'I am not sure what I am doing...',
		'dependency' => 'name',
	),
));
$form->addField(array(
	'name' => 'final_content',
	'type' => 'content',
	'value' => '<p>This is a content type block, that in this case is being added to the end of the form.</p>',
	'dependency' => 'notifications',
	'dependency-value' => '',
));*/
$form->addField(array(
	'name' => 'submit',
	'type' => 'submit',
	'value' => 'Submit',
	'cancel' => 'Cancel',
	'cancel_url' => 'http://google.com',
	'cancel_id' => 'cancel',
	'cancel_target' => '_blank',
));

?>

<!DOCTYPE html>
<html>
<head>
	<title>henchFORM Demo</title>
	<link href="css/henchFORM.css" rel="stylesheet" type="text/css" />
	<script src="js/henchFORM.js" type="text/javascript"></script>
	<style>
	html { margin: 0; padding: 0; height: 100%; font-size: 20px; }
	body { margin: 0; padding: 0; height: 100%; font-family: 'Arial', sans-serif; font-size: 1em; }
	body .hf-form { margin: auto; padding: 1em; max-width: 40em; }
	*, *:before, *:after { -webkit-box-sizing: border-box; -moz-box-sizing: border-box; -ms-box-sizing: border-box; box-sizing: border-box; }

	@media only screen and (min-width: 34em){
		body .hf-form { padding: 2em; }
	}

	.hf-field.hf-blur { background: #bad4ff; }
	.hf-field.hf-focus { background: #ffe1ba; }
	.hf-field.hf-invalid { background: #ffbaba; }
	.hf-field.hf-valid { background: #baffe6; }
	</style>
</head>
<body>

<?php print($form->getHTML()); ?>
<?php print($form->getHTML()); ?>

</body>
</html>

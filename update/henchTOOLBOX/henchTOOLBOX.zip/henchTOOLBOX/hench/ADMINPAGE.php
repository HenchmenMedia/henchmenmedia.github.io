<?php
/**
 * henchADMINPAGE
 * Description: henchADMINPAGE is designed to give developers a powerful and easy way to create robust admin pages.
 * Version: 0.0.1
**/

if (!defined('ABSPATH')) exit;

class henchADMINPAGE {
	public $options = array(
		'parent_slug' => '',
		'page_title' => '',
		'menu_title' => '',
		'capability' => '',
		'menu_slug' => '',
		'icon_url' => '',
		'position' => '',
		'header_description' => '',
		'header_icon' => 'dashicons-hammer',
		'header_icon_bg' => '#999',
		'content' => '',
		'form_fields' => array(),
		'docs_url' => '',
		'docs_api' => '',
		'side' => '',
		'footer' => '',
	);
	public $form;

	public function __construct($options){
		$this->options = array_merge($this->options, $options);
		if (is_admin()) {
			add_action('admin_menu', array($this, 'menu'));
		}
	}

	public function menu() {
		if($this->options['parent_slug']){
			add_submenu_page($this->options['parent_slug'], $this->options['page_title'], $this->options['menu_title'], $this->options['capability'], $this->options['menu_slug'], array($this, 'page'));
		} else {
			add_menu_page($this->options['page_title'], $this->options['menu_title'], $this->options['capability'], $this->options['menu_slug'], array($this, 'page'), $this->options['icon_url'], $this->options['position']);
		}
	}

	public function page(){
		echo '<section class="hench-admin'.($this->options['parent_slug'] ? ' hench-'.$this->options['parent_slug'].'-child' : '').' hench-'.$this->options['menu_slug'].'">';
		$this->header();
		echo '<div class="hench-body">';
		$this->content();
		$this->form();
		echo '</div>';
		$this->side();
		$this->footer();
		echo '</section>';
	}

	protected function header(){
		$html = '<header class="hench-header">
			<div class="hench-header-icon dashicons-before '.$this->options['header_icon'].'" style="background-color: '.$this->options['header_icon_bg'].';"></div>
			<h1 class="hench-header-title">'.$this->options['page_title'].'</h1>
			'.($this->options['header_description'] ? '<h3 class="hench-header-description">'.$this->options['header_description'].'</h3>' : '').'
		</header>';
		echo $html;
	}

	protected function side(){
		echo '<aside class="hench-side">';
		$this->docs();
		echo henchTOOLBOX::callable_content($this->options['side']);
		echo '</aside>';
	}

	protected function docs(){
		if($this->options['docs_url']){
			echo '<div class="hench-docs">';
			echo '<a href="'.$this->options['docs_url'].'" data-docs="'.$this->options['docs_api'].'" class="hench-side-button hench-docs-button dashicons-before dashicons-sos" target="_blank">Documentation</a>';
			echo '</div>';
		}
	}

	protected function content() {
		echo '<div class="hench-content">'.henchTOOLBOX::callable_content($this->options['content']).'</div>';
	}

	protected function form(){
		if(count($this->options['form_fields'])){
			$this->form = new henchFORM(array('id'=>'form_'.$this->options['menu_slug'], 'class'=>'hf-default hench-form hench-form-'.$this->options['menu_slug']));
			$this->form->addHook('success', array($this, 'form_save'));
			$this->form->addHook('failed', array($this, 'form_fail'));
			$this->form->addFields(array_merge(array(
				array(
					'name'=>'hfmessage',
				),
				array(
					'name' => 'nonce_'.$this->options['menu_slug'],
					'type' => 'hidden',
					'value' => wp_create_nonce('nonce_'.$this->options['menu_slug']),
					'required' => true,
				),
			), $this->options['form_fields']));
			echo $this->form->getHTML();
		}
	}

	public function form_save(){
		$nonce = isset($_POST['nonce_'.$this->options['menu_slug']]) ? $_POST['nonce_'.$this->options['menu_slug']] : '';
		if (!wp_verify_nonce($nonce, 'nonce_'.$this->options['menu_slug'])) {
			$this->form->failed('Error: Nonce Failed, Try Again');
			return;
		}
		$this->form->success('HENCHED: Settings saved.');

		$values = apply_filters('hench_admin_page_'.$this->options['menu_slug'].'_values', $this->form->postValues(), $this->options, $this->form);
		unset($values['nonce_'.$this->options['menu_slug']]);
		foreach($values as $k=>$v){
			update_option($k, $v);
		}
		do_action('hench_admin_page_'.$this->options['menu_slug'].'_save', $this->options, $this->form);
	}

	public function form_fail(){
		do_action('hench_admin_page_'.$this->options['menu_slug'].'_fail', $this->options, $this->form);
	}

	protected function footer(){
		echo '<footer class="hench-footer">'.henchTOOLBOX::callable_content($this->options['footer']).'<div class="hench-powered">Henched by henchTOOLBOX.</div></footer>';
	}

}

<?php
/**
 * henchPLUGIN
 * Description: henchPLUGIN is designed to give developers a powerful and easy way to create robust plugins. All henchPLUGINS are extended from the henchPLUGIN class.
 * Version: 0.0.1
**/

if (!defined('ABSPATH')) exit;

class henchPLUGIN {
	protected $version = '0.0.0';
	protected $options = array();
	protected $update_url = '';
	private $default_options = array(
		'priority' => 10,
	);

	public function __construct() {
		$this->get_options();
		$this->check_plugin_update();
		$this->setup_actions();
	}

	public function slug() {
		return get_called_class();
	}

	public function option($key='') {
		return !empty($this->options[$key]) ? $this->options[$key] : '';
	}

	public function options() {
		return $this->options;
	}

	public function set_option($key, $value) {
		if(is_array($key) && !empty($key)){
			$this->options = array_merge($this->options, $key);
			$this->update_options();
		} else if (isset($this->options[$key]) && isset($value)) {
			$this->options[$key] = $value;
			$this->update_options();
		}
	}

	private function get_options() {
		$options = maybe_unserialize(get_option($this->slug().'_options')) ?: array();
		$this->options = array_merge($this->default_options, $this->options, $options);
	}

	private function update_options() {
		update_option($this->slug().'_options', $this->options);
	}

	public function options_form($fields=array()) {
		return apply_filters($this->slug().'_options_form', $fields);
	}

	public function save_options($form) {
		$this->set_option($this->form->postValues());
	}

	public function activate() {
	}

	public function update() {
	}

	private function check_plugin_update(){
		if(is_admin() && !empty($this->update_url) && strpos($this->update_url, 'wordpress.org')===false){
			add_filter('pre_set_site_transient_update_plugins', array($this, 'check_plugin_update_url'));
		}
	}

	public function check_plugin_update_url($transient){
		if (empty($transient->checked[$this->slug().'/'.$this->slug().'.php'])) {
			return $transient;
		}

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->update_url);
		curl_setopt($ch, CURLOPT_TIMEOUT, 3);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$result = curl_exec($ch);
		curl_close($ch);

		if (empty($result)) {
			return $transient;
		}

		if ($data = json_decode($result)) {
			if (version_compare($transient->checked[$this->slug().'/'.$this->slug().'.php'], $data->new_version, '<')) {
				$transient->response[$this->slug().'/'.$this->slug().'.php'] = $data;
			}
		}

		return $transient;
	}

	public function deactivate() {
	}

	public function uninstall() {
		delete_option($this->slug().'_options');
	}

	protected function setup_actions(){
		add_action('plugins_loaded', array($this, 'setup_action'), $this->options['priority']);
	}

	public function setup_action() {
		add_action($this->slug().'_setup', array($this, 'setup'));
		do_action($this->slug().'_setup');
	}

	public function setup() {
	}

}

<?php
/**
 * henchMETABOX
 * Description: henchMETABOX is designed to give developers a powerful and easy way to create robust meta boxes.
 * Version: 0.0.1
**/

if (!defined('ABSPATH')) exit;

class henchMETABOX {
	protected $id;
	protected $title;
	protected $screen;
	protected $context;
	protected $priority;
	protected $callback_args;
	protected $post;
	protected $form;
	protected $value = array();

	public function __construct($form='', $args=array()){
		if(!is_a($form, 'henchFORM')){ return; }
		apply_filters('hench_metabox_'.$args['id'].'_args', $args);
		apply_filters('hench_metabox_'.$args['id'].'_form', $form);
		$this->form = $form;

		$args = array_merge(array(
			'id' => '',
			'title' => '',
			'screen' => array(),
			'context' => 'normal',
			'priority' => 'default',
			'callback_args' => null,
		), $args);
		$this->id = $args['id'];
		$this->title = $args['title'];
		$this->screen = $args['screen'];
		$this->context = $args['context'];
		$this->priority = $args['priority'];
		$this->callback_args = $args['callback_args'];

		add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
		add_action('save_post', array($this, 'save_post'));
	}

	public function add_meta_boxes(){
		add_meta_box($this->id, $this->title, array($this, 'meta_box'), $this->screen, $this->context, $this->priority, $this->callback_args);
	}

	public function meta_box($post){
		$this->post = $post;

		wp_nonce_field($this->id, $this->id.'_nonce');

		$this->get_meta_values();
		echo $this->form->getHTML(false);
	}

	public function get_meta_values(){
		foreach($this->form->field as $field){
			if($this->post->__isset($field->setting('name'))){
				$field->setting('value', $this->get_meta($field->setting('name')));
			}
		}
	}

	public function get_meta($metakey){
		return maybe_unserialize(get_post_meta($this->post->ID, $metakey, true));
	}

	public function save_post($post_id){
		$nonce = isset($_POST[$this->id.'_nonce']) ? $_POST[$this->id.'_nonce'] : '';
		if(!wp_verify_nonce($nonce, $this->id)){ return $post_id; }
		if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE){ return $post_id; }

		$this->post = get_post($post_id);

		$this->form->parseForm();

		$this->check_meta();
		$this->set_meta();
		$this->save_meta();
	}

	public function check_meta(){

	}

	protected function set_meta(){
		$this->value = array_merge($this->form->value, $this->value);
	}

	protected function save_meta(){
		foreach($this->value as $k=>$v){
			if(!empty($k) && isset($v)){
				update_post_meta($this->post->ID, $k, $v);
			}
		}
	}

}

<?php
/**
 * henchTOOLBOX
 * Description: henchTOOLBOX is designed to give developers a powerful and easy way to create robust WordPress websites. Include the henchTOOLBOX plugin in your WP install and you will have access to a suite of features to improve your WordPress development experience.
 * Version: 0.0.1
**/

if (!defined('ABSPATH')) exit;

class henchTOOLBOX extends henchPLUGIN {
	protected $version = '0.0.1';
	protected $update_url = 'https://update.henchmen.media/henchTOOLBOX/';
	protected $options = array(
		'priority' => 1,
	);
	protected $deps = array();

	public function setup(){
		henchPLUGIN('henchFORM_lib');
		henchPLUGIN('henchDEPENDENCY');
		henchPLUGIN('henchADMIN');

		add_shortcode('home_url', array($this, 'home_url'));
		add_shortcode('uploads_url', array($this, 'uploads_url'));
		add_shortcode('parent_theme_url', array($this, 'template_url'));
		add_shortcode('child_theme_url', array($this, 'stylesheet_url'));

		add_filter('the_content', array($this, 'do_custom_loop'), 2);
		add_shortcode('custom_loop', array($this, 'custom_loop_shortcode'));

		if(is_admin()){
			add_filter('content_save_pre', array($this, 'filter_magic_urls'), 999);
			add_filter('content_edit_pre', array($this, 'unfilter_magic_urls'), 1);
			add_filter('the_content', array($this, 'unfilter_magic_urls'), 1);
			add_filter('rest_request_after_callbacks', array($this, 'rest_unfilter_magic_urls'), 10);
		}
	}

	public function home_url($atts){
		$atts = shortcode_atts(array('id'=>''), $atts);
		return $atts['id'] && get_permalink($atts['id']) ? esc_url(get_permalink($atts['id'])) : home_url();
	}

	public function uploads_url($atts){
		$atts = shortcode_atts(array('id'=>''), $atts);
		return $atts['id'] && wp_get_attachment_url($atts['id']) ? esc_url(wp_get_attachment_url($atts['id'])) : wp_get_upload_dir()['baseurl'];
	}

	public function template_url(){
		return get_template_directory_uri();
	}

	public function stylesheet_url(){
		return get_stylesheet_directory_uri();
	}

	public function filter_magic_urls($content){
		preg_match_all('/'.preg_quote(wp_get_upload_dir()['baseurl'],'/').'[^#?"\'\\\,\s()<>]+/', $content, $matches);
		foreach($matches[0] as $match){
			$attachment = attachment_url_to_postid($match);
			if(!empty($attachment)){
				$pos = strpos($content, $match);
				if($pos!==false){
					$content = substr_replace($content, '[uploads id='.$attachment.']', $pos, strlen($match));
				}
			}
		}
		preg_match_all('/'.preg_quote(home_url(),'/').'[^#?"\'\\\,\s()<>]+/', $content, $matches);
		foreach($matches[0] as $match){
			$postid = url_to_postid($match);
			if(!empty($postid) && $match!=home_url('/')){
				$pos = strpos($content, $match);
				if($pos!==false){
					$content = substr_replace($content, '[home_url id='.$postid.']', $pos, strlen($match));
				}
			}
		}
		$content = str_replace(wp_get_upload_dir()['baseurl'], '[uploads_url]', $content);
		$content = str_replace(home_url(), '[home_url]', $content);
		return $content;
	}

	public function unfilter_magic_urls($content){
		$content = str_replace(array('[home_url]'), home_url(), $content);
		$content = str_replace('[uploads_url]', wp_get_upload_dir()['baseurl'], $content);
		preg_match_all('/\[uploads[^\]]*\]/i', $content, $matches);
		foreach($matches[0] as $match){
			$pos = strpos($content, $match);
			if($pos!==false){
				$content = substr_replace($content, do_shortcode($match), $pos, strlen($match));
			}
		}
		preg_match_all('/\[home_url[^\]]*\]/i', $content, $matches);
		foreach($matches[0] as $match){
			$pos = strpos($content, $match);
			if($pos!==false){
				$content = substr_replace($content, do_shortcode($match), $pos, strlen($match));
			}
		}
		return $content;
	}

	public function rest_unfilter_magic_urls($result){
		if(!empty($result->data['content']['raw'])){
			$result->data['content']['raw'] = $this->unfilter_magic_urls($result->data['content']['raw']);
		}
		return $result;
	}

	public static function callable_content($val=''){
		if (is_callable($val)) {
			return call_user_func($val);
		} elseif(!is_array($val)) {
			return $val;
		}
		return '';
	}

	public static function do_custom_loop($content=''){
		preg_match_all('/\[custom_loop([^\]]*)\](.*?)\[\/custom_loop\]/is', $content, $matches);
		for($i=0;$i<count($matches[0]);$i++){
			$content = str_replace($matches[0][$i], do_shortcode($matches[0][$i]), $content);
		}
		return $content;
	}

	public function custom_loop_shortcode($atts, $content) {
		$atts = shortcode_atts(array(
			'type'     => 'post',
			'id'       => '',
			'cat_type' => 'category_name',
			'cat'      => '',
			'meta_key' => '',
			'num'      => '-1',
			'orderby'  => 'date title',
			'order'    => 'DESC',
			'status'   => 'publish',
			'size'     => 'medium',
		), $atts);

		$args = array(
			'post_type'        => $atts['type'],
			$atts['cat_type']  => $atts['cat'],
			'meta_key'         => $atts['meta_key'],
			'posts_per_page'   => $atts['num'],
			'include'          => $atts['id'],
			'orderby'          => $atts['orderby'],
			'order'            => $atts['order'],
			'post_status'      => $atts['status'],
		);

		$posts = get_posts($args);

		$result = '';
		foreach($posts as $post){
			$vals['ID'] = $post->ID;
			$vals['post_title'] = $post->post_title;
			$vals['post_content'] = apply_filters('the_content', $post->post_content);
			$vals['post_excerpt'] = apply_filters('the_excerpt', $post->post_excerpt) ?: wp_trim_words($post->post_content);
			$vals['post_date'] = get_the_date('', $post->ID);
			$vals['permalink'] = get_the_permalink($post->ID);
			$vals['thumbnail'] = get_the_post_thumbnail($post->ID, $atts['size']);
			$item = $content;
			preg_match_all('/\{([A-Z][A-Z0-9_-]*)([^}]*)\}(.*?)\{\/\1\}/is',$item,$matches);
			for($i=0;$i<=count($matches[0]);$i++){
				if(array_key_exists($matches[1][$i],$vals)){
					$val = $vals[$matches[1][$i]];
				} else {
					$val = get_post_meta($post->ID, $matches[1][$i], true);
				}
				if($val){
					$item = str_ireplace($matches[0][$i], $matches[3][$i], $item);
				} else {
					$item = str_ireplace($matches[0][$i], '', $item);
				}
			}
			preg_match_all('/\{([A-Z][A-Z0-9_-]*)([^}]*)\}/is',$item,$matches);
			for($i=0;$i<count($matches[0]);$i++){
				if(array_key_exists($matches[1][$i],$vals)){
					$val = $vals[$matches[1][$i]];
				} else {
					$val = get_post_meta($post->ID, $matches[1][$i], true);
				}
				$item = str_ireplace($matches[0][$i], $val, $item);
			}
			$result.= $item;
		}
		return $result;
	}

}

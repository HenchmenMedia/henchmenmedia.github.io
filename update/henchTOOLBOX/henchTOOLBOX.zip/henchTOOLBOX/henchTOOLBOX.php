<?php
/**
 * Plugin Name: henchTOOLBOX
 * Plugin URI: https://henchmenmedia.github.io/
 * Description: henchTOOLBOX makes your WordPress install hench (strong, fit, and having well-developed muscles). henchTOOLBOX is the base plugin for all henchPLUGINS. It takes care of library and dependency management, so that henchPLUGINS are DRY, which keeps code from repeating or being included multiple times. How does this help you? It keeps your WordPress install clean and light, providing more muscle with less fat.
 * Version: 0.0.1
 * Author: Henchmen Media
 * License: GPL3
 **/

if (!defined('ABSPATH')) exit;

define('henchPATH', plugin_dir_path(__FILE__));
define('henchURL', plugin_dir_url(__FILE__));

require_once(henchPATH.'hench/PLUGIN.php');
require_once(henchPATH.'hench/THEME.php');
require_once(henchPATH.'hench/FORM_lib.php');
require_once(henchPATH.'hench/DEPENDENCY.php');
require_once(henchPATH.'hench/ADMINPAGE.php');
require_once(henchPATH.'hench/ADMIN.php');
require_once(henchPATH.'hench/METABOX.php');
require_once(henchPATH.'hench/TOOLBOX.php');

function henchPLUGIN($class, $atts=array()){
	global $henchTOOLBOX;
	if(class_exists($class)){
		$henchTOOLBOX[$class] = new $class($atts);
	}
}

function henchTHEME($class, $atts=array()){
	henchPLUGIN($class, $atts);
}

henchPLUGIN('henchTOOLBOX');
